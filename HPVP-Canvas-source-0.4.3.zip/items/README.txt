Place PNG item textures in this folder using the texture names from plugins/HPVP-Canvas/items.yml. Run /canvas pack build after changing textures.

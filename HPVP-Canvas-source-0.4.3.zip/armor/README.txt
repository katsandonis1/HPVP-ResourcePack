Place armor layer PNGs here. Use <texture>.png for the humanoid layer and <texture>_leggings.png for the leggings layer. Run /canvas pack build after changing textures.

plugins {
    java
}

group = "com.skyforge"
version = "0.4.3"

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(21)
}

tasks.jar {
    archiveBaseName.set("HPVP-Canvas")
}

tasks.register<JavaExec>("exportResourcePack") {
    group = "build"
    description = "Builds a host-ready Minecraft resource-pack ZIP from this project's asset folders."
    dependsOn(tasks.classes)
    val main = sourceSets.main.get()
    classpath = main.runtimeClasspath + main.compileClasspath
    mainClass.set("com.skyforge.canvas.pack.ResourcePackCli")
    val packOutput = layout.buildDirectory.file("generated/HPVP-Canvas-resourcepack.zip")
    outputs.file(packOutput)
    args(
        projectDir.absolutePath,
        project.file("src/main/resources/items.yml").absolutePath,
        packOutput.get().asFile.absolutePath
    )
}

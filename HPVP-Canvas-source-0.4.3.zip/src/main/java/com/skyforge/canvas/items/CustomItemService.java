package com.skyforge.canvas.items;

import com.skyforge.canvas.CanvasPlugin;
import com.skyforge.canvas.util.PluginMessages;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.Equippable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class CustomItemService {
    private final CanvasPlugin plugin;
    private final Map<String, ItemDefinition> items = new LinkedHashMap<>();
    private final NamespacedKey itemIdKey;

    public CustomItemService(CanvasPlugin plugin) {
        this.plugin = plugin;
        itemIdKey = new NamespacedKey(plugin, "item_id");
    }

    public void reload(YamlConfiguration config) {
        items.clear();
        ConfigurationSection section = config.getConfigurationSection("items");
        if (section == null) {
            plugin.getLogger().warning(PluginMessages.text("items.yml is missing the 'items' section."));
            return;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection item = section.getConfigurationSection(id);
            if (item == null) {
                continue;
            }
            Material material = Material.matchMaterial(item.getString("material", ""));
            if (material == null || material.isAir()) {
                plugin.getLogger().warning(PluginMessages.text("Skipping item '" + id + "': unknown or invalid material."));
                continue;
            }
            items.put(id.toLowerCase(Locale.ROOT), new ItemDefinition(
                id,
                material,
                item.getString("name", id),
                item.getStringList("lore"),
                item.getString("model", "canvas:" + id),
                item.getConfigurationSection("equipment")
            ));
        }
    }

    public List<String> ids() {
        return List.copyOf(items.keySet());
    }

    public ItemStack create(String id) {
        ItemDefinition definition = items.get(id.toLowerCase(Locale.ROOT));
        if (definition == null) {
            return null;
        }
        ItemStack stack = new ItemStack(definition.material());
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plugin.glyphText().parse(definition.name()));
        if (!definition.lore().isEmpty()) {
            meta.lore(definition.lore().stream().map(plugin.glyphText()::parse).toList());
        }
        NamespacedKey model = NamespacedKey.fromString(definition.model());
        if (model == null) {
            plugin.getLogger().warning(PluginMessages.text("Invalid item model key on item '" + id + "': " + definition.model()));
        } else {
            meta.setItemModel(model);
        }
        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, id.toLowerCase(Locale.ROOT));
        stack.setItemMeta(meta);

        ConfigurationSection equipment = definition.equipment();
        if (equipment != null) {
            try {
                EquipmentSlot slot = EquipmentSlot.valueOf(equipment.getString("slot", "HEAD").toUpperCase(Locale.ROOT));
                Key asset = Key.key(equipment.getString("asset", "canvas:armor"));
                stack.setData(DataComponentTypes.EQUIPPABLE, Equippable.equippable(slot).assetId(asset).build());
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning(PluginMessages.text("Invalid equipment settings on item '" + id + "': " + exception.getMessage()));
            }
        }
        return stack;
    }

    public boolean give(Player player, String id) {
        ItemStack stack = create(id);
        if (stack == null) {
            return false;
        }
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
        overflow.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        return true;
    }

    private record ItemDefinition(
        String id,
        Material material,
        String name,
        List<String> lore,
        String model,
        ConfigurationSection equipment
    ) {}
}

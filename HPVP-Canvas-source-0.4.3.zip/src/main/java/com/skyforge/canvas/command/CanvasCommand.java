package com.skyforge.canvas.command;

import com.skyforge.canvas.CanvasPlugin;
import com.skyforge.canvas.pack.ResourcePackBuilder.BuildResult;
import com.skyforge.canvas.util.PluginMessages;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class CanvasCommand implements CommandExecutor, TabCompleter {
    private final CanvasPlugin plugin;

    public CanvasCommand(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadCanvas();
            sender.sendMessage(PluginMessages.component("HPVP-Canvas configuration reloaded."));
            return true;
        }
        if (args[0].equalsIgnoreCase("pack") && args.length >= 2 && args[1].equalsIgnoreCase("build")) {
            buildPack(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("pack") && args.length == 2 && args[1].equalsIgnoreCase("update")) {
            updatePack(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("pack") && args.length >= 2 && args[1].equalsIgnoreCase("set")) {
            if (args.length != 3) {
                sender.sendMessage(PluginMessages.component("Usage: /canvas pack set <url>"));
                return true;
            }
            sender.sendMessage(PluginMessages.component("Checking the hosted ZIP against the generated resource pack..."));
            plugin.setResourcePackUrl(args[2], result -> {
                if (!result.success()) {
                    sender.sendMessage(PluginMessages.component("Could not set the resource pack: " + result.error()));
                    plugin.getLogger().warning(PluginMessages.text("Resource-pack URL check failed: " + result.error()));
                } else if (result.sent() == 0) {
                    sender.sendMessage(PluginMessages.component("Resource-pack URL verified and saved. Players will be prompted when they join."));
                } else {
                    sender.sendMessage(PluginMessages.component("Resource-pack URL verified and saved. Sent the optional download prompt to " + result.sent() + " online player(s)."));
                }
            });
            return true;
        }
        if (args[0].equalsIgnoreCase("give") && args.length >= 3) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(PluginMessages.component("That player is not online."));
                return true;
            }
            if (!plugin.customItems().give(target, args[2])) {
                sender.sendMessage(PluginMessages.component("Unknown custom item. Available: " + String.join(", ", plugin.customItems().ids())));
                return true;
            }
            sender.sendMessage(PluginMessages.component("Gave " + args[2] + " to " + target.getName() + "."));
            return true;
        }
        help(sender);
        return true;
    }

    private void help(CommandSender sender) {
        sender.sendMessage(PluginMessages.component("HPVP-Canvas commands: /canvas reload, /canvas pack build, /canvas pack set <url>, /canvas pack update, /canvas give <player> <item>"));
    }

    private void updatePack(CommandSender sender) {
        String configuredUrl = plugin.getConfig().getString("resource-pack.url", "");
        String url = configuredUrl == null ? "" : configuredUrl.trim();
        if (url.isEmpty()) {
            sender.sendMessage(PluginMessages.component("No resource-pack URL is configured. Host resourcepack.zip, then run /canvas pack set <url>."));
            return;
        }
        sender.sendMessage(PluginMessages.component("Verifying the current resource-pack ZIP at the configured URL..."));
        plugin.setResourcePackUrl(url, result -> {
            if (!result.success()) {
                sender.sendMessage(PluginMessages.component("Pack update was not sent: " + result.error()));
                plugin.getLogger().warning(PluginMessages.text("Pack update failed: " + result.error()));
            } else if (result.sent() == 0) {
                sender.sendMessage(PluginMessages.component("Resource pack verified and updated. Players joining now will be prompted."));
            } else {
                sender.sendMessage(PluginMessages.component("Resource pack verified and update prompt sent to " + result.sent() + " online player(s)."));
            }
        });
    }

    private void buildPack(CommandSender sender) {
        try {
            BuildResult result = plugin.packBuilder().build();
            sender.sendMessage(PluginMessages.component("Built resource pack: " + result.resourcePack()));
            sender.sendMessage(PluginMessages.component("SHA-1: " + result.sha1()));
            if (result.pauseDataPack() != null) {
                sender.sendMessage(PluginMessages.component("Built pause-menu data pack: " + result.pauseDataPack()));
            }
            for (String warning : result.warnings()) {
                sender.sendMessage(PluginMessages.component("Warning: " + warning));
            }
            sender.sendMessage(PluginMessages.component("Download this ZIP from the Paper server and upload it unchanged. Then run /canvas pack set <url>, or /canvas pack update to verify the saved URL and prompt online players."));
        } catch (IOException | IllegalArgumentException exception) {
            sender.sendMessage(PluginMessages.component("Pack build failed: " + exception.getMessage()));
            plugin.getLogger().warning(PluginMessages.text("Pack build failed: " + exception.getMessage()));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("reload", "pack", "give").stream().filter(value -> value.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("pack")) {
            return List.of("build", "set", "update").stream().filter(value -> value.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return plugin.customItems().ids();
        }
        return List.of();
    }
}

package com.skyforge.canvas;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.event.EventPriority;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class CanvasListener implements Listener {
    private final CanvasPlugin plugin;

    public CanvasListener(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            plugin.applyTo(player);
            plugin.refreshTabForAll();
            plugin.refreshScoreboardForAll();
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.removePlayer(event.getPlayer());
        plugin.ranks().remove(event.getPlayer());
        Bukkit.getScheduler().runTask(plugin, plugin::refreshTabForAll);
        Bukkit.getScheduler().runTask(plugin, plugin::refreshScoreboardForAll);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.refreshTabForAll();
            plugin.refreshScoreboardForAll();
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        var rankPrefix = plugin.ranks().chatPrefix(event.getPlayer());
        var separator = plugin.ranks().chatSeparator();
        event.renderer(ChatRenderer.viewerUnaware((source, displayName, message) ->
            net.kyori.adventure.text.Component.empty()
                .append(rankPrefix)
                .append(displayName)
                .append(separator)
                .append(message)));
    }
}

package com.skyforge.canvas.ui;

import com.skyforge.canvas.CanvasPlugin;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public final class TabController {
    private final CanvasPlugin plugin;
    private YamlConfiguration config;

    public TabController(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload(YamlConfiguration config) {
        this.config = config;
        applyAll();
    }

    public void applyAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            apply(player);
        }
    }

    public void apply(Player player) {
        if (config == null || !config.getBoolean("tab.enabled", true)) {
            if (!Component.empty().equals(player.playerListHeader()) || !Component.empty().equals(player.playerListFooter())) {
                player.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
            }
            if (player.playerListName() != null) {
                player.playerListName(null);
            }
            return;
        }
        String header = String.join("\n", replaceLines(config.getStringList("tab.header"), player));
        String footer = String.join("\n", replaceLines(config.getStringList("tab.footer"), player));
        Component headerComponent = plugin.glyphText().parse(header);
        Component footerComponent = plugin.glyphText().parse(footer);
        if (!headerComponent.equals(player.playerListHeader()) || !footerComponent.equals(player.playerListFooter())) {
            player.sendPlayerListHeaderAndFooter(headerComponent, footerComponent);
        }

        String playerNameFormat = config.getString("tab.player-name-format", "%player%");
        Component playerName = plugin.glyphText().parse(replace(playerNameFormat, player));
        if (!playerName.equals(player.playerListName())) {
            player.playerListName(playerName);
        }
    }

    private List<String> replaceLines(List<String> lines, Player player) {
        List<String> replaced = new ArrayList<>(lines.size());
        for (String line : lines) {
            replaced.add(replace(line, player));
        }
        return replaced;
    }

    public String replace(String line, Player player) {
        List<? extends Player> worldPlayers = Bukkit.getOnlinePlayers().stream()
            .filter(online -> online.getWorld().getUID().equals(player.getWorld().getUID()))
            .sorted(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER))
            .toList();
        int limit = Math.max(1, Math.min(40, config.getInt("tab.world-roster-max-players", 8)));
        List<String> names = new ArrayList<>();
        for (Player worldPlayer : worldPlayers.stream().limit(limit).toList()) {
            names.add(plugin.ranks().rankIcon(worldPlayer) + plugin.ranks().rankName(worldPlayer)
                + " <white>" + worldPlayer.getName() + "</white>");
        }
        if (worldPlayers.size() > limit) {
            names.add("<gray>+" + (worldPlayers.size() - limit) + " more</gray>");
        }
        return line.replace("%player%", player.getName())
            .replace("%world%", player.getWorld().getName())
            .replace("%ping%", Integer.toString(Math.max(0, player.getPing())))
            .replace("%online%", Integer.toString(Bukkit.getOnlinePlayers().size()))
            .replace("%max_players%", Integer.toString(Bukkit.getMaxPlayers()))
            .replace("%world_players%", Integer.toString(worldPlayers.size()))
            .replace("%world_player_list%", names.isEmpty() ? "<gray>None</gray>" : String.join("<dark_gray>, </dark_gray>", names))
            .replace("%rank_icon%", plugin.ranks().rankIcon(player))
            .replace("%rank%", plugin.ranks().rankName(player));
    }
}

package com.skyforge.canvas.ui;

import com.skyforge.canvas.CanvasPlugin;
import com.skyforge.canvas.util.PluginMessages;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scheduler.BukkitTask;

/** One shared tick task for tab, scoreboard, rank-cache, and animation refreshes. */
public final class UiRefreshController {
    private static final int DEFAULT_INTERVAL = 20;
    private static final int MIN_INTERVAL = 5;
    private static final int MAX_INTERVAL = 1200;

    private final CanvasPlugin plugin;
    private BukkitTask task;
    private int tabInterval = DEFAULT_INTERVAL;
    private int scoreboardInterval = DEFAULT_INTERVAL;
    private long tick;

    public UiRefreshController(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload(ConfigurationSection config) {
        tabInterval = readInterval(config, "ui.tab-update-interval-ticks", DEFAULT_INTERVAL);
        scoreboardInterval = readInterval(config, "ui.scoreboard-update-interval-ticks", DEFAULT_INTERVAL);
        tick = 0L;
        if (task == null) {
            task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        }
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private int readInterval(ConfigurationSection config, String path, int fallback) {
        int value = config == null ? fallback : config.getInt(path, fallback);
        if (value < MIN_INTERVAL || value > MAX_INTERVAL) {
            plugin.getLogger().warning(PluginMessages.text(path + " must be between " + MIN_INTERVAL + " and "
                + MAX_INTERVAL + " ticks; using " + fallback + "."));
            return fallback;
        }
        return value;
    }

    private void tick() {
        tick++;
        boolean animationChanged = plugin.glyphText().advanceAnimations();
        boolean tabDue = tick % tabInterval == 0;
        boolean scoreboardDue = tick % scoreboardInterval == 0;
        boolean ranksChanged = tabDue && plugin.ranks().refreshAll();
        if (tabDue || animationChanged || ranksChanged) {
            plugin.refreshTabForAll();
        }
        if (scoreboardDue || animationChanged || ranksChanged) {
            plugin.refreshScoreboardForAll();
        }
    }
}

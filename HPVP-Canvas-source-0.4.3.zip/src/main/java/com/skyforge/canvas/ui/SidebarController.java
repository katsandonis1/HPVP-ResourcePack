package com.skyforge.canvas.ui;

import com.skyforge.canvas.CanvasPlugin;
import com.skyforge.canvas.util.PluginMessages;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.RenderType;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class SidebarController {
    private final CanvasPlugin plugin;
    private final Map<UUID, Scoreboard> scoreboards = new HashMap<>();
    private YamlConfiguration config;

    public SidebarController(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload(YamlConfiguration config) {
        this.config = config;
        scoreboards.clear();
        if (config.getBoolean("scoreboard.enabled", true)) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                createFor(player);
            }
        } else {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }
    }

    public void apply(Player player) {
        if (config == null || !config.getBoolean("scoreboard.enabled", true)) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            return;
        }
        if (!scoreboards.containsKey(player.getUniqueId())) {
            createFor(player);
        }
        update(player);
    }

    public void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            apply(player);
        }
    }

    public void remove(Player player) {
        scoreboards.remove(player.getUniqueId());
    }

    public void stop() {
        if (Bukkit.getScoreboardManager() != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }
        scoreboards.clear();
    }

    private void createFor(Player player) {
        if (Bukkit.getScoreboardManager() == null) {
            return;
        }
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective(
            "canvas_sidebar",
            Criteria.DUMMY,
            plugin.glyphText().parse(replace(config.getString("scoreboard.title", "HPVP-Canvas"), player)),
            RenderType.INTEGER
        );
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.numberFormat(NumberFormat.blank());

        List<String> lines = config.getStringList("scoreboard.lines");
        if (lines.size() > 15) {
            plugin.getLogger().warning(PluginMessages.text("scoreboard.yml has more than 15 lines; extra lines are ignored."));
            lines = lines.subList(0, 15);
        }
        for (int index = 0; index < lines.size(); index++) {
            String teamName = "cv_line_" + index;
            Team team = scoreboard.registerNewTeam(teamName);
            String entry = "§" + "0123456789abcdef".charAt(index);
            team.addEntry(entry);
            objective.getScore(entry).setScore(lines.size() - index);
        }
        scoreboards.put(player.getUniqueId(), scoreboard);
        player.setScoreboard(scoreboard);
        update(player);
    }

    private void update(Player player) {
        Scoreboard scoreboard = scoreboards.get(player.getUniqueId());
        if (scoreboard == null || config == null) {
            return;
        }
        Objective objective = scoreboard.getObjective("canvas_sidebar");
        if (objective != null) {
            Component title = plugin.glyphText().parse(replace(config.getString("scoreboard.title", "HPVP-Canvas"), player));
            if (!title.equals(objective.displayName())) {
                objective.displayName(title);
            }
        }
        List<String> lines = config.getStringList("scoreboard.lines");
        if (lines.size() > 15) {
            lines = lines.subList(0, 15);
        }
        for (int index = 0; index < lines.size(); index++) {
            Team team = scoreboard.getTeam("cv_line_" + index);
            if (team == null) {
                continue;
            }
            Component prefix = plugin.glyphText().parse(replace(lines.get(index), player));
            if (!prefix.equals(team.prefix())) {
                team.prefix(prefix);
            }
            if (!Component.empty().equals(team.suffix())) {
                team.suffix(Component.empty());
            }
        }
    }

    private String replace(String line, Player player) {
        return plugin.tabController().replace(line, player)
            .replace("%health%", Integer.toString((int) Math.ceil(player.getHealth())));
    }
}

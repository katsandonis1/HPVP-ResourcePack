package com.skyforge.canvas;

import com.skyforge.canvas.command.CanvasCommand;
import com.skyforge.canvas.items.CustomItemService;
import com.skyforge.canvas.pack.HostedPackVerifier;
import com.skyforge.canvas.pack.ResourcePackBuilder;
import com.skyforge.canvas.ui.SidebarController;
import com.skyforge.canvas.ui.TabController;
import com.skyforge.canvas.ui.UiRefreshController;
import com.skyforge.canvas.util.GlyphText;
import com.skyforge.canvas.util.PluginMessages;
import com.skyforge.canvas.util.RankService;
import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

public final class CanvasPlugin extends JavaPlugin {
    private static final String PREVIOUS_BUNDLED_LEFT_SHA256 =
        "b5c43075b95aaec1649eb843aa3b091fbe88db751da53a4cb5f8b234be4e661f";

    private YamlConfiguration tabConfig;
    private YamlConfiguration scoreboardConfig;
    private YamlConfiguration itemsConfig;
    private YamlConfiguration pauseConfig;
    private YamlConfiguration ranksConfig;
    private GlyphText glyphText;
    private RankService rankService;
    private TabController tabController;
    private SidebarController sidebarController;
    private UiRefreshController uiRefreshController;
    private CustomItemService customItemService;
    private ResourcePackBuilder resourcePackBuilder;
    private final AtomicLong packSetRequests = new AtomicLong();
    private volatile boolean packVerificationWarningLogged;

    @Override
    public void onEnable() {
        migrateLegacyDataFolder();
        saveBundledFiles();
        createWorkingDirectories();
        glyphText = new GlyphText(this);
        rankService = new RankService(this);
        tabController = new TabController(this);
        sidebarController = new SidebarController(this);
        uiRefreshController = new UiRefreshController(this);
        customItemService = new CustomItemService(this);
        resourcePackBuilder = new ResourcePackBuilder(this);
        reloadCanvas();

        CanvasCommand command = new CanvasCommand(this);
        getCommand("canvas").setExecutor(command);
        getCommand("canvas").setTabCompleter(command);
        Bukkit.getPluginManager().registerEvents(new CanvasListener(this), this);

        for (Player player : Bukkit.getOnlinePlayers()) {
            applyTo(player);
        }
        getLogger().info(PluginMessages.text("HPVP-Canvas enabled. Build the pack with /canvas pack build, then set its download URL with /canvas pack set <url>."));
    }

    @Override
    public void onDisable() {
        if (sidebarController != null) {
            sidebarController.stop();
        }
        if (uiRefreshController != null) {
            uiRefreshController.stop();
        }
    }

    private void saveBundledFiles() {
        saveDefaultConfig();
        for (String resource : List.of("tab.yml", "scoreboard.yml", "items.yml", "pause.yml", "ranks.yml")) {
            if (!new File(getDataFolder(), resource).exists()) {
                saveResource(resource, false);
            }
        }
        installBundledGlyph("left.png", PREVIOUS_BUNDLED_LEFT_SHA256);
        installBundledGlyph("owner.png", null);
        installBundledGlyph("hellenic_logo.png", null);
    }

    private void installBundledGlyph(String filename, String replaceIfSha256) {
        Path destination = getDataFolder().toPath().resolve("glyphs").resolve(filename);
        try {
            Files.createDirectories(destination.getParent());
            boolean install = !Files.exists(destination);
            if (!install && replaceIfSha256 != null && Files.isRegularFile(destination)) {
                byte[] digest = MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(destination));
                install = HexFormat.of().formatHex(digest).equalsIgnoreCase(replaceIfSha256);
            }
            if (!install) {
                return;
            }
            try (InputStream input = getResource("glyphs/" + filename)) {
                if (input == null) {
                    getLogger().warning(PluginMessages.text("Bundled image glyphs/" + filename + " is missing from the plugin JAR."));
                    return;
                }
                Files.copy(input, destination, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception exception) {
            getLogger().warning(PluginMessages.text("Could not install the bundled image glyph " + filename + ": " + exception.getMessage()));
        }
    }

    private void migrateLegacyDataFolder() {
        Path current = getDataFolder().toPath();
        Path previous = current.resolveSibling("Canvas");
        if (!Files.isDirectory(previous)) {
            return;
        }

        try (var files = Files.walk(previous)) {
            boolean copied = false;
            for (Path source : files.toList()) {
                Path destination = current.resolve(previous.relativize(source));
                if (Files.isDirectory(source)) {
                    Files.createDirectories(destination);
                } else if (!Files.exists(destination)) {
                    Files.createDirectories(destination.getParent());
                    Files.copy(source, destination, StandardCopyOption.COPY_ATTRIBUTES);
                    copied = true;
                }
            }
            if (copied) {
                getLogger().info(PluginMessages.text("Imported existing settings and assets into the HPVP-Canvas folder."));
            }
        } catch (Exception exception) {
            getLogger().warning(PluginMessages.text("Could not import old Canvas data: " + exception.getMessage()));
        }
    }

    private void createWorkingDirectories() {
        for (String directory : List.of("glyphs", "items", "armor", "pack-source/assets")) {
            new File(getDataFolder(), directory).mkdirs();
        }
    }

    public void reloadCanvas() {
        reloadConfig();
        tabConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "tab.yml"));
        scoreboardConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "scoreboard.yml"));
        itemsConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "items.yml"));
        pauseConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "pause.yml"));
        ranksConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "ranks.yml"));
        glyphText.reload();
        rankService.reload(ranksConfig);
        customItemService.reload(itemsConfig);
        tabController.reload(tabConfig);
        sidebarController.reload(scoreboardConfig);
        uiRefreshController.reload(getConfig());
    }

    public void applyTo(Player player) {
        rankService.refresh(player);
        tabController.apply(player);
        sidebarController.apply(player);
        sendResourcePack(player);
    }

    public void setResourcePackUrl(String rawUrl, Consumer<PackSetResult> callback) {
        String candidate = rawUrl == null ? "" : rawUrl.trim();
        long requestId = packSetRequests.incrementAndGet();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            PackSetResult checkResult;
            URI uri = null;
            String hash = "";
            try {
                uri = parseResourcePackUri(candidate);
                Path data = getDataFolder().toPath();
                Path pack = data.resolve("resourcepack.zip");
                Path hashFile = data.resolve("resourcepack.sha1");
                if (!Files.isRegularFile(pack) || !Files.isRegularFile(hashFile)) {
                    throw new IllegalStateException("Build the resource pack first with /canvas pack build.");
                }
                hash = Files.readString(hashFile).trim();
                if (!hash.matches("(?i)[0-9a-f]{40}")) {
                    throw new IllegalStateException("The generated resource-pack SHA-1 is missing or invalid. Run /canvas pack build again.");
                }
                String actualLocalHash = ResourcePackBuilder.sha1(pack);
                if (!hash.equalsIgnoreCase(actualLocalHash)) {
                    throw new IllegalStateException("The local resourcepack.zip changed after it was built. Run /canvas pack build again.");
                }
                HostedPackVerifier.verify(uri, Files.size(pack), hash);
                checkResult = new PackSetResult(true, 0, "", uri.toASCIIString(), hash);
            } catch (Exception exception) {
                String message = exception.getMessage();
                checkResult = new PackSetResult(false, 0,
                    message == null || message.isBlank() ? "The hosted resource pack could not be verified." : message,
                    null, null);
            }

            PackSetResult finalCheckResult = checkResult;
            URI verifiedUri = uri;
            String verifiedHash = hash;
            Bukkit.getScheduler().runTask(this, () -> {
                if (!isEnabled()) {
                    return;
                }
                if (requestId != packSetRequests.get()) {
                    callback.accept(new PackSetResult(false, 0,
                        "A newer resource-pack URL check replaced this one. Run /canvas pack set again if needed.", null, null));
                    return;
                }
                if (!finalCheckResult.success()) {
                    callback.accept(finalCheckResult);
                    return;
                }
                try {
                    getConfig().set("resource-pack.url", verifiedUri.toASCIIString());
                    getConfig().set("resource-pack.required", false);
                    getConfig().set("resource-pack.verified-sha1", verifiedHash.toLowerCase(Locale.ROOT));
                    saveConfig();
                    packVerificationWarningLogged = false;
                    int sent = sendResourcePackToAll();
                    callback.accept(new PackSetResult(true, sent, "", verifiedUri.toASCIIString(), verifiedHash));
                } catch (Exception exception) {
                    callback.accept(new PackSetResult(false, 0,
                        "The URL was verified, but its settings could not be saved: " + exception.getMessage(), null, null));
                }
            });
        });
    }

    private static URI parseResourcePackUri(String rawUrl) throws URISyntaxException {
        URI uri;
        try {
            uri = new URI(rawUrl);
        } catch (URISyntaxException exception) {
            throw new URISyntaxException(rawUrl, "The resource-pack URL is not valid.");
        }
        String scheme = uri.getScheme();
        if (uri.getHost() == null || uri.getUserInfo() != null || uri.getFragment() != null
            || scheme == null || (!scheme.equalsIgnoreCase("https") && !scheme.equalsIgnoreCase("http"))) {
            throw new URISyntaxException(rawUrl, "Use a public HTTP or HTTPS direct-download URL for the resource-pack ZIP.");
        }
        return uri;
    }

    public int sendResourcePackToAll() {
        int sent = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (sendResourcePack(player)) {
                sent++;
            }
        }
        return sent;
    }

    private boolean sendResourcePack(Player player) {
        String url = getConfig().getString("resource-pack.url", "").trim();
        Path pack = getDataFolder().toPath().resolve("resourcepack.zip");
        Path hashFile = getDataFolder().toPath().resolve("resourcepack.sha1");
        if (url.isEmpty() || !Files.isRegularFile(pack) || !Files.isRegularFile(hashFile)) {
            return false;
        }
        try {
            String hash = Files.readString(hashFile).trim();
            if (!hash.matches("(?i)[0-9a-f]{40}")) {
                getLogger().warning(PluginMessages.text("Cannot send the resource pack because resourcepack.sha1 is invalid. Run /canvas pack build."));
                return false;
            }
            String verifiedHash = getConfig().getString("resource-pack.verified-sha1", "").trim();
            if (!hash.equalsIgnoreCase(verifiedHash)) {
                if (!packVerificationWarningLogged) {
                    getLogger().warning(PluginMessages.text("The hosted pack has not been verified for the current build. Upload resourcepack.zip and run /canvas pack set <url> before prompting players."));
                    packVerificationWarningLogged = true;
                }
                return false;
            }
            ResourcePackInfo info = ResourcePackInfo.resourcePackInfo()
                .uri(URI.create(url))
                .hash(hash.toLowerCase(java.util.Locale.ROOT))
                .build();
            ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(getConfig().getBoolean("resource-pack.required", false))
                .prompt(glyphText.parse(getConfig().getString("resource-pack.prompt", "Download the server pack?")))
                .build();
            player.sendResourcePacks(request);
            return true;
        } catch (Exception exception) {
            getLogger().warning(PluginMessages.text("Could not send the resource pack to " + player.getName() + ": " + exception.getMessage()));
            return false;
        }
    }

    public void refreshTabForAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            tabController.apply(player);
        }
    }

    public void refreshScoreboardForAll() {
        sidebarController.refreshAll();
    }

    public void removePlayer(Player player) {
        sidebarController.remove(player);
    }

    public YamlConfiguration tabConfig() {
        return tabConfig;
    }

    public YamlConfiguration scoreboardConfig() {
        return scoreboardConfig;
    }

    public YamlConfiguration itemsConfig() {
        return itemsConfig;
    }

    public YamlConfiguration pauseConfig() {
        return pauseConfig;
    }

    public YamlConfiguration ranksConfig() {
        return ranksConfig;
    }

    public GlyphText glyphText() {
        return glyphText;
    }

    public CustomItemService customItems() {
        return customItemService;
    }

    public RankService ranks() {
        return rankService;
    }

    public TabController tabController() {
        return tabController;
    }

    public ResourcePackBuilder packBuilder() {
        return resourcePackBuilder;
    }

    public record PackSetResult(boolean success, int sent, String error, String url, String sha1) {}
}

package com.skyforge.canvas.util;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import org.bukkit.configuration.ConfigurationSection;

/** Resolves configured image tags to deterministic bitmap-font glyph variants. */
public final class GlyphRegistry {
    private static final Pattern IMAGE_TAG = Pattern.compile("<image:([^<>]*)>");
    private static final Pattern UI_TAG = Pattern.compile("<(image|animate):([^<>]*)>");
    private static final Pattern COLOR_HEX = Pattern.compile("#[0-9a-fA-F]{6}");
    private static final int FIRST_GLYPH = 0xE000;
    private static final int MAX_GLYPHS = 6400;
    private static final int HARD_MAX_SIZE = 256;
    private static final int HARD_MAX_SOURCE_SIZE = 2048;
    private static final Map<String, String> NAMED_COLORS = namedColors();
    private static final Comparator<VariantKey> KEY_ORDER = Comparator
        .comparing(VariantKey::name)
        .thenComparingInt(VariantKey::width)
        .thenComparingInt(VariantKey::height)
        .thenComparing(key -> key.alignment().name())
        .thenComparing(key -> key.filter().name());

    private final Defaults defaults;
    private final Map<String, ImageAsset> images;
    private final Map<VariantKey, GlyphVariant> variants;
    private final List<String> warnings;

    private GlyphRegistry(Defaults defaults, Map<String, ImageAsset> images,
                          Map<VariantKey, GlyphVariant> variants, List<String> warnings) {
        this.defaults = defaults;
        this.images = Collections.unmodifiableMap(new LinkedHashMap<>(images));
        this.variants = Collections.unmodifiableMap(new LinkedHashMap<>(variants));
        this.warnings = List.copyOf(warnings);
    }

    public static GlyphRegistry load(Path imageDirectory, ConfigurationSection config,
                                     Collection<String> configuredText, ConfigurationSection ranks) throws IOException {
        List<String> warnings = new ArrayList<>();
        Defaults defaults = readDefaults(config, warnings);
        Map<String, ImageAsset> images = discoverImages(imageDirectory, defaults.maxSize(), warnings);
        Set<VariantKey> requested = new TreeSet<>(KEY_ORDER);
        Set<String> emittedWarnings = new LinkedHashSet<>();

        for (String text : configuredText) {
            if (text == null || text.isEmpty()) {
                continue;
            }
            Matcher matcher = UI_TAG.matcher(text);
            String withoutCompleteTags = UI_TAG.matcher(text).replaceAll("");
            if (withoutCompleteTags.contains("<image:") || withoutCompleteTags.contains("<animate:")) {
                emittedWarnings.add("Malformed image or animation tag in UI configuration. Close every tag with '>'.");
            }
            while (matcher.find()) {
                if (matcher.group(1).equals("image")) {
                    registerRequested(matcher.group(2), defaults, images, requested, emittedWarnings);
                } else {
                    registerAnimationFrames(matcher.group(2), config, defaults, images, requested, emittedWarnings);
                }
            }
        }
        warnings.addAll(emittedWarnings);

        Map<VariantKey, GlyphVariant> variants = new LinkedHashMap<>();
        int index = 0;
        for (VariantKey key : requested) {
            if (index >= MAX_GLYPHS) {
                warnings.add("The configured UI uses more than " + MAX_GLYPHS + " unique image variants; extra variants are unavailable.");
                break;
            }
            ImageAsset asset = images.get(key.name());
            if (asset == null) {
                continue;
            }
            variants.put(key, new GlyphVariant(key, (char) (FIRST_GLYPH + index), asset.path()));
            index++;
        }
        return new GlyphRegistry(defaults, images, variants, warnings);
    }

    private static void registerRequested(String body, Defaults defaults, Map<String, ImageAsset> images,
                                          Set<VariantKey> requested, Set<String> warnings) {
        ParsedTag parsed = parse(body, defaults, images);
        if (parsed.error() != null) {
            warnings.add(parsed.error());
            return;
        }
        ImageAsset source = images.get(parsed.key().name());
        if (source != null && (parsed.key().width() > source.width() || parsed.key().height() > source.height())) {
            warnings.add("Glyph image '" + source.name() + "' is smaller than its requested " + parsed.key().width()
                + "x" + parsed.key().height() + " output. Upscaling cannot restore missing image detail.");
        }
        requested.add(parsed.key());
    }

    private static void registerAnimationFrames(String body, ConfigurationSection config, Defaults defaults,
                                                Map<String, ImageAsset> images, Set<VariantKey> requested,
                                                Set<String> warnings) {
        String[] parts = body.split(",", -1);
        String animationName = parts[0].trim().toLowerCase(Locale.ROOT);
        if (!animationName.matches("[a-z0-9_-]+")) {
            warnings.add("Invalid animation tag name in <animate:" + body + ">.");
            return;
        }
        List<String> frames = config == null ? List.of() : config.getStringList("animations." + animationName + ".frames");
        if (frames.isEmpty()) {
            warnings.add("Unknown animation '" + animationName + "' or it has no frames. Configure animations." + animationName + ".frames in config.yml.");
            return;
        }
        String suffix = parts.length > 1 ? body.substring(body.indexOf(',') + 1) : "";
        for (String frame : frames) {
            if (frame == null || frame.isBlank()) {
                warnings.add("Animation '" + animationName + "' contains an empty frame name.");
                continue;
            }
            registerRequested(frame.trim() + (suffix.isEmpty() ? "" : "," + suffix), defaults, images, requested, warnings);
        }
    }

    public static List<String> configuredText(ConfigurationSection tab, ConfigurationSection scoreboard,
                                              ConfigurationSection pause, ConfigurationSection ranks,
                                              Path glyphDirectory) {
        List<String> values = new ArrayList<>();
        if (tab != null) {
            values.addAll(tab.getStringList("tab.header"));
            values.addAll(tab.getStringList("tab.footer"));
            addIfPresent(values, tab.getString("tab.player-name-format"));
        }
        if (scoreboard != null) {
            addIfPresent(values, scoreboard.getString("scoreboard.title"));
            values.addAll(scoreboard.getStringList("scoreboard.lines"));
        }
        if (pause != null) {
            addIfPresent(values, pause.getString("pause-menu.button-title"));
            addIfPresent(values, pause.getString("pause-menu.title"));
            addIfPresent(values, pause.getString("pause-menu.message"));
            addIfPresent(values, pause.getString("pause-menu.close-button"));
        }
        if (ranks != null) {
            ConfigurationSection rankSection = ranks.getConfigurationSection("ranks");
            if (rankSection != null) {
                for (String id : rankSection.getKeys(false)) {
                    ConfigurationSection rank = rankSection.getConfigurationSection(id);
                    if (rank != null) {
                        addIfPresent(values, rank.getString("display-name"));
                        String icon = rank.getString("icon", "");
                        addIfPresent(values, icon);
                        if ((icon == null || icon.isBlank()) && containsImageFile(glyphDirectory, id)) {
                            values.add(automaticRankIconTag(id));
                        }
                    }
                }
            }
        }

        return List.copyOf(values);
    }

    /** Returns the default glyph tag used when a rank has a matching <rank-id>.png. */
    public static String automaticRankIconTag(String rankId) {
        return "<image:" + rankId.toLowerCase(Locale.ROOT) + ",size:10,align:center>";
    }

    /** Auto-detection is case-insensitive, matching glyph discovery. */
    public static boolean containsImageFile(Path glyphDirectory, String imageName) {
        if (glyphDirectory == null || imageName == null || !Files.isDirectory(glyphDirectory)) {
            return false;
        }
        String expected = imageName.toLowerCase(Locale.ROOT) + ".png";
        Path direct = glyphDirectory.resolve(expected);
        if (Files.isRegularFile(direct)) {
            return true;
        }
        try (var files = Files.list(glyphDirectory)) {
            return files.anyMatch(path -> path.getFileName().toString().equalsIgnoreCase(expected));
        } catch (IOException ignored) {
            return false;
        }
    }

    private static void addIfPresent(List<String> values, String value) {
        if (value != null) {
            values.add(value);
        }
    }

    public ParsedGlyph resolve(String tagBody) {
        ParsedTag parsed = parse(tagBody, defaults, images);
        if (parsed.error() != null) {
            return null;
        }
        GlyphVariant variant = variants.get(parsed.key());
        if (variant == null) {
            return null;
        }
        return new ParsedGlyph(variant.character(), parsed.color());
    }

    public List<GlyphVariant> variants() {
        return List.copyOf(variants.values());
    }

    public Map<String, ImageAsset> images() {
        return images;
    }

    public List<String> warnings() {
        return warnings;
    }

    private static Defaults readDefaults(ConfigurationSection config, List<String> warnings) {
        String configuredSize = config == null ? "original" : config.getString("image-glyphs.default-size", "original");
        configuredSize = configuredSize == null || configuredSize.isBlank() ? "original" : configuredSize.trim();
        Integer defaultSize = null;
        if (!configuredSize.equalsIgnoreCase("original")) {
            try {
                defaultSize = Integer.parseInt(configuredSize);
                if (defaultSize < 1 || defaultSize > HARD_MAX_SIZE) {
                    throw new NumberFormatException("outside supported range");
                }
            } catch (NumberFormatException exception) {
                warnings.add("image-glyphs.default-size must be 'original' or a number from 1 to " + HARD_MAX_SIZE + "; using original image dimensions.");
                defaultSize = null;
            }
        }

        int maxSize = config == null ? 64 : config.getInt("image-glyphs.max-size", 64);
        if (maxSize < 1) {
            warnings.add("image-glyphs.max-size must be at least 1; using 64.");
            maxSize = 64;
        } else if (maxSize > HARD_MAX_SIZE) {
            warnings.add("image-glyphs.max-size cannot exceed " + HARD_MAX_SIZE + "; using " + HARD_MAX_SIZE + ".");
            maxSize = HARD_MAX_SIZE;
        }

        String defaultColor = config == null ? "none" : config.getString("image-glyphs.default-color", "none");
        String normalizedColor = normalizeColor(defaultColor);
        if (normalizedColor == null && defaultColor != null && !defaultColor.isBlank()
            && !defaultColor.equalsIgnoreCase("none") && !defaultColor.equalsIgnoreCase("inherit")) {
            warnings.add("Invalid image-glyphs.default-color '" + defaultColor + "'; using none.");
        }

        String configuredAlignment = config == null ? "bottom" : config.getString("image-glyphs.default-align", "bottom");
        Alignment alignment = parseAlignment(configuredAlignment);
        if (alignment == null) {
            warnings.add("image-glyphs.default-align must be top, center, or bottom; using bottom.");
            alignment = Alignment.BOTTOM;
        }
        String configuredFilter = config == null ? "nearest" : config.getString("image-glyphs.default-filter", "nearest");
        SamplingFilter filter = parseFilter(configuredFilter);
        if (filter == null) {
            warnings.add("image-glyphs.default-filter must be nearest, bilinear, or bicubic; using nearest.");
            filter = SamplingFilter.NEAREST;
        }
        return new Defaults(defaultSize, maxSize, normalizedColor, alignment, filter);
    }

    private static Map<String, ImageAsset> discoverImages(Path directory, int maxSize, List<String> warnings) throws IOException {
        Map<String, ImageAsset> images = new LinkedHashMap<>();
        if (!Files.isDirectory(directory)) {
            return images;
        }
        try (var files = Files.list(directory)) {
            for (Path file : files
                .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                .toList()) {
                String filename = file.getFileName().toString();
                String name = filename.substring(0, filename.length() - 4).toLowerCase(Locale.ROOT);
                if (!name.matches("[a-z0-9_-]+")) {
                    warnings.add("Skipping glyph with invalid filename: " + filename);
                    continue;
                }
                if (images.containsKey(name)) {
                    warnings.add("Skipping duplicate glyph filename (names are case-insensitive): " + filename);
                    continue;
                }
                BufferedImage image;
                try {
                    image = ImageIO.read(file.toFile());
                } catch (IOException exception) {
                    warnings.add("Could not read glyph image '" + filename + "': " + exception.getMessage());
                    continue;
                }
                if (image == null || image.getWidth() < 1 || image.getHeight() < 1) {
                    warnings.add("Invalid or unreadable glyph image: " + filename);
                    continue;
                }
                if (image.getWidth() > HARD_MAX_SOURCE_SIZE || image.getHeight() > HARD_MAX_SOURCE_SIZE) {
                    warnings.add("Glyph image '" + filename + "' exceeds the safe source limit of "
                        + HARD_MAX_SOURCE_SIZE + "x" + HARD_MAX_SOURCE_SIZE + ".");
                    continue;
                }
                images.put(name, new ImageAsset(name, file, image.getWidth(), image.getHeight()));
            }
        }
        return images;
    }

    private static ParsedTag parse(String body, Defaults defaults, Map<String, ImageAsset> images) {
        String[] parts = body.split(",", -1);
        String name = parts[0].trim().toLowerCase(Locale.ROOT);
        if (!name.matches("[a-z0-9_-]+")) {
            return ParsedTag.error("Invalid image tag name in <image:" + body + ">.");
        }
        ImageAsset image = images.get(name);
        if (image == null) {
            return ParsedTag.error("Unknown or invalid glyph image '" + name + "'. Add a readable PNG named " + name + ".png under plugins/HPVP-Canvas/glyphs/.");
        }

        Map<String, String> options = new HashMap<>();
        for (int index = 1; index < parts.length; index++) {
            String[] option = parts[index].trim().split(":", 2);
            if (option.length != 2 || option[0].isBlank() || option[1].isBlank()) {
                return ParsedTag.error("Invalid option in <image:" + body + ">. Use key:value pairs separated by commas.");
            }
            String key = option[0].trim().toLowerCase(Locale.ROOT);
            String value = option[1].trim();
            if (!Set.of("size", "width", "height", "color", "align", "filter").contains(key)) {
                return ParsedTag.error("Unsupported image option '" + key + "' in <image:" + body + ">. Supported options: size, width, height, color, align, filter.");
            }
            if (options.putIfAbsent(key, value) != null) {
                return ParsedTag.error("Duplicate image option '" + key + "' in <image:" + body + ">.");
            }
        }

        boolean hasSize = options.containsKey("size");
        boolean hasWidth = options.containsKey("width");
        boolean hasHeight = options.containsKey("height");
        if (hasSize && (hasWidth || hasHeight)) {
            return ParsedTag.error("Use either size or width and height in <image:" + body + ">, not both.");
        }
        if (hasWidth != hasHeight) {
            return ParsedTag.error("Image tag <image:" + body + "> must provide both width and height.");
        }

        int width;
        int height;
        if (hasSize) {
            Integer size = parseDimension(options.get("size"), defaults.maxSize());
            if (size == null) {
                return ParsedTag.error("Invalid image size in <image:" + body + ">. Use a whole number from 1 to " + defaults.maxSize() + ".");
            }
            width = size;
            height = size;
        } else if (hasWidth) {
            Integer parsedWidth = parseDimension(options.get("width"), defaults.maxSize());
            Integer parsedHeight = parseDimension(options.get("height"), defaults.maxSize());
            if (parsedWidth == null || parsedHeight == null) {
                return ParsedTag.error("Invalid image dimensions in <image:" + body + ">. Width and height must be whole numbers from 1 to " + defaults.maxSize() + ".");
            }
            width = parsedWidth;
            height = parsedHeight;
        } else if (defaults.defaultSize() != null) {
            width = defaults.defaultSize();
            height = defaults.defaultSize();
            if (width > defaults.maxSize()) {
                return ParsedTag.error("image-glyphs.default-size exceeds image-glyphs.max-size (" + defaults.maxSize() + ").");
            }
        } else {
            width = image.width();
            height = image.height();
        }
        if (width > defaults.maxSize() || height > defaults.maxSize()) {
            return ParsedTag.error("Image dimensions in <image:" + body + "> exceed image-glyphs.max-size ("
                + defaults.maxSize() + "). Add a smaller size or raise the configured limit.");
        }

        String color = defaults.color();
        if (options.containsKey("color")) {
            color = normalizeColor(options.get("color"));
            if (color == null && !options.get("color").equalsIgnoreCase("none")
                && !options.get("color").equalsIgnoreCase("inherit")) {
                return ParsedTag.error("Invalid image color '" + options.get("color") + "' in <image:" + body
                    + ">. Use a supported color name, #RRGGBB, or none.");
            }
        }

        Alignment alignment = defaults.alignment();
        if (options.containsKey("align")) {
            alignment = parseAlignment(options.get("align"));
            if (alignment == null) {
                return ParsedTag.error("Invalid image alignment in <image:" + body + ">. Use top, center, or bottom.");
            }
        }
        SamplingFilter filter = defaults.filter();
        if (options.containsKey("filter")) {
            filter = parseFilter(options.get("filter"));
            if (filter == null) {
                return ParsedTag.error("Invalid image filter in <image:" + body + ">. Use nearest, bilinear, or bicubic.");
            }
        }
        return ParsedTag.valid(new VariantKey(name, width, height, alignment, filter), color);
    }

    private static Integer parseDimension(String value, int maxSize) {
        try {
            int dimension = Integer.parseInt(value);
            return dimension >= 1 && dimension <= maxSize ? dimension : null;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private static Alignment parseAlignment(String value) {
        if (value == null) {
            return null;
        }
        return switch (value.trim().toLowerCase(Locale.ROOT)) {
            case "top" -> Alignment.TOP;
            case "center" -> Alignment.CENTER;
            case "bottom" -> Alignment.BOTTOM;
            default -> null;
        };
    }

    private static SamplingFilter parseFilter(String value) {
        if (value == null) {
            return null;
        }
        return switch (value.trim().toLowerCase(Locale.ROOT)) {
            case "nearest" -> SamplingFilter.NEAREST;
            case "bilinear" -> SamplingFilter.BILINEAR;
            case "bicubic" -> SamplingFilter.BICUBIC;
            default -> null;
        };
    }

    private static String normalizeColor(String value) {
        if (value == null || value.isBlank() || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("inherit")) {
            return null;
        }
        String color = value.trim().toLowerCase(Locale.ROOT);
        if (COLOR_HEX.matcher(color).matches()) {
            return color;
        }
        return NAMED_COLORS.get(color);
    }

    private static Map<String, String> namedColors() {
        Map<String, String> colors = new LinkedHashMap<>();
        colors.put("black", "#000000");
        colors.put("dark_blue", "#0000aa");
        colors.put("dark_green", "#00aa00");
        colors.put("dark_aqua", "#00aaaa");
        colors.put("dark_red", "#aa0000");
        colors.put("dark_purple", "#aa00aa");
        colors.put("gold", "#ffaa00");
        colors.put("gray", "#aaaaaa");
        colors.put("dark_gray", "#555555");
        colors.put("blue", "#5555ff");
        colors.put("green", "#55ff55");
        colors.put("aqua", "#55ffff");
        colors.put("red", "#ff5555");
        colors.put("light_purple", "#ff55ff");
        colors.put("yellow", "#ffff55");
        colors.put("white", "#ffffff");
        colors.put("orange", "#ffaa00");
        colors.put("pink", "#ff55ff");
        colors.put("cyan", "#55ffff");
        colors.put("purple", "#aa00aa");
        colors.put("lime", "#55ff55");
        colors.put("navy", "#0000aa");
        colors.put("teal", "#00aaaa");
        return Collections.unmodifiableMap(colors);
    }

    public enum Alignment {
        TOP,
        CENTER,
        BOTTOM
    }

    public enum SamplingFilter {
        NEAREST,
        BILINEAR,
        BICUBIC
    }

    public record ImageAsset(String name, Path path, int width, int height) {}

    public record GlyphVariant(VariantKey key, char character, Path source) {
        public String textureName() {
            return String.format(Locale.ROOT, "glyph_%04x.png", (int) character);
        }
    }

    public record ParsedGlyph(char character, String color) {}

    private record Defaults(Integer defaultSize, int maxSize, String color, Alignment alignment, SamplingFilter filter) {}
    public record VariantKey(String name, int width, int height, Alignment alignment, SamplingFilter filter) {}
    private record ParsedTag(VariantKey key, String color, String error) {
        private static ParsedTag valid(VariantKey key, String color) {
            return new ParsedTag(key, color, null);
        }

        private static ParsedTag error(String message) {
            return new ParsedTag(null, null, message);
        }
    }
}

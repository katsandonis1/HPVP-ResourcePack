package com.skyforge.canvas.util;

import net.kyori.adventure.text.Component;

public final class PluginMessages {
    public static final String PREFIX = "ʜᴘᴠᴘ | ";

    private PluginMessages() {}

    public static Component component(String message) {
        return Component.text(PREFIX + message);
    }

    public static String text(String message) {
        return PREFIX + message;
    }
}

package com.skyforge.canvas.util;

import com.skyforge.canvas.CanvasPlugin;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;

public final class GlyphText {
    public static final Key FONT = Key.key("canvas", "ui");
    private static final Pattern IMAGE_TOKEN = Pattern.compile("<(image|animate):([^<>]*)>");
    private final CanvasPlugin plugin;
    private final GlyphAnimations animations = new GlyphAnimations();
    private volatile GlyphRegistry registry;

    public GlyphText(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        Path directory = plugin.getDataFolder().toPath().resolve("glyphs");
        List<String> configuredText = GlyphRegistry.configuredText(
            plugin.tabConfig(), plugin.scoreboardConfig(), plugin.pauseConfig(), plugin.ranksConfig(), directory);
        for (String warning : animations.reload(plugin.getConfig())) {
            plugin.getLogger().warning(PluginMessages.text(warning));
        }
        try {
            registry = GlyphRegistry.load(directory, plugin.getConfig(), configuredText, plugin.ranksConfig());
            for (String warning : registry.warnings()) {
                plugin.getLogger().warning(PluginMessages.text(warning));
            }
        } catch (IOException exception) {
            registry = null;
            plugin.getLogger().warning(PluginMessages.text("Could not load image glyphs: " + exception.getMessage()));
        }
    }

    public GlyphRegistry registry() {
        return registry;
    }

    public boolean advanceAnimations() {
        return animations.advance();
    }

    public Component parse(String input) {
        if (input == null || input.isEmpty()) {
            return Component.empty();
        }
        Matcher matcher = IMAGE_TOKEN.matcher(input);
        StringBuilder normalized = new StringBuilder();
        Map<String, GlyphRegistry.ParsedGlyph> placeholders = new LinkedHashMap<>();
        int cursor = 0;
        while (matcher.find()) {
            normalized.append(input, cursor, matcher.start());
            String type = matcher.group(1);
            String tagBody = matcher.group(2);
            if (type.equals("animate")) {
                String resolved = animations.resolveFrameTag(tagBody);
                if (resolved == null) {
                    normalized.append("[animate:").append(tagBody).append(']');
                    cursor = matcher.end();
                    continue;
                }
                tagBody = resolved;
            }
            GlyphRegistry current = registry;
            GlyphRegistry.ParsedGlyph glyph = current == null ? null : current.resolve(tagBody);
            if (glyph == null) {
                normalized.append(type.equals("animate") ? "[animate:" : "[image:").append(matcher.group(2)).append(']');
            } else {
                String placeholder = "HPVPCANVASIMAGEPLACEHOLDER" + placeholders.size() + "END";
                normalized.append(placeholder);
                placeholders.put(placeholder, glyph);
            }
            cursor = matcher.end();
        }
        normalized.append(input.substring(cursor));
        // Keep an unfinished or malformed image token visible without passing it to MiniMessage as markup.
        String safeText = normalized.toString().replace("<image:", "[image:").replace("<animate:", "[animate:");
        Component result = MiniMessage.miniMessage().deserialize(safeText);
        for (Map.Entry<String, GlyphRegistry.ParsedGlyph> entry : placeholders.entrySet()) {
            GlyphRegistry.ParsedGlyph parsed = entry.getValue();
            result = result.replaceText(TextReplacementConfig.builder()
                .matchLiteral(entry.getKey())
                .replacement((match, builder) -> {
                    builder.content(Character.toString(parsed.character())).font(FONT);
                    if (parsed.color() != null) {
                        builder.color(TextColor.fromHexString(parsed.color()));
                    }
                    return builder.build();
                })
                .build());
        }
        return result;
    }
}

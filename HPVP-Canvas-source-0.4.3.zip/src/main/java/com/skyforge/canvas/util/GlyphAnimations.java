package com.skyforge.canvas.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import org.bukkit.configuration.ConfigurationSection;

/** Tick-based frame clock for <animate:name> tags. */
public final class GlyphAnimations {
    private static final int DEFAULT_INTERVAL = 10;
    private static final int MIN_INTERVAL = 2;
    private static final int MAX_INTERVAL = 1200;

    private final AtomicLong ticks = new AtomicLong();
    private volatile Map<String, Animation> animations = Map.of();

    public List<String> reload(ConfigurationSection config) {
        List<String> warnings = new ArrayList<>();
        Map<String, Animation> loaded = new LinkedHashMap<>();
        ConfigurationSection section = config == null ? null : config.getConfigurationSection("animations");
        if (section != null) {
            for (String rawName : section.getKeys(false)) {
                String name = rawName.toLowerCase(Locale.ROOT);
                if (!name.matches("[a-z0-9_-]+")) {
                    warnings.add("Skipping animation with invalid name '" + rawName + "'. Use lowercase letters, numbers, underscores, or hyphens.");
                    continue;
                }
                ConfigurationSection definition = section.getConfigurationSection(rawName);
                if (definition == null) {
                    warnings.add("Animation '" + name + "' must be a configuration section.");
                    continue;
                }
                List<String> frames = definition.getStringList("frames").stream()
                    .map(frame -> frame == null ? "" : frame.trim().toLowerCase(Locale.ROOT))
                    .filter(frame -> !frame.isEmpty() && frame.matches("[a-z0-9_-]+"))
                    .distinct()
                    .toList();
                if (frames.size() < 2) {
                    warnings.add("Animation '" + name + "' needs at least two valid PNG frame names.");
                    continue;
                }
                if (frames.size() != definition.getStringList("frames").size()) {
                    warnings.add("Animation '" + name + "' has invalid or duplicate frame names; invalid entries were skipped.");
                }
                int interval = definition.getInt("frame-interval-ticks", DEFAULT_INTERVAL);
                if (interval < MIN_INTERVAL || interval > MAX_INTERVAL) {
                    warnings.add("Animation '" + name + "' frame-interval-ticks must be between " + MIN_INTERVAL
                        + " and " + MAX_INTERVAL + "; using " + DEFAULT_INTERVAL + ".");
                    interval = DEFAULT_INTERVAL;
                }
                loaded.put(name, new Animation(frames, interval));
            }
        }
        ticks.set(0L);
        animations = Map.copyOf(loaded);
        return List.copyOf(warnings);
    }

    /** Advances the shared animation clock; returns true when any visible frame may have changed. */
    public boolean advance() {
        long tick = ticks.incrementAndGet();
        for (Animation animation : animations.values()) {
            if (animation.frames().size() > 1 && tick % animation.intervalTicks() == 0) {
                return true;
            }
        }
        return false;
    }

    /** Resolves an animation tag body, preserving the options after its name. */
    public String resolveFrameTag(String body) {
        String[] parts = body.split(",", -1);
        String name = parts[0].trim().toLowerCase(Locale.ROOT);
        Animation animation = animations.get(name);
        if (animation == null || animation.frames().isEmpty()) {
            return null;
        }
        long frameNumber = (ticks.get() / animation.intervalTicks()) % animation.frames().size();
        String frame = animation.frames().get((int) frameNumber);
        String options = parts.length > 1 ? body.substring(body.indexOf(',') + 1) : "";
        return frame + (options.isEmpty() ? "" : "," + options);
    }

    public boolean isEmpty() {
        return animations.isEmpty();
    }

    private record Animation(List<String> frames, int intervalTicks) {}
}

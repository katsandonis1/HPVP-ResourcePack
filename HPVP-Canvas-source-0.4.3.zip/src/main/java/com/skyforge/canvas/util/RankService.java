package com.skyforge.canvas.util;

import com.skyforge.canvas.CanvasPlugin;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/** Loads configured permission ranks and caches safe, immutable chat/tab snapshots. */
public final class RankService {
    private final CanvasPlugin plugin;
    private final Map<UUID, Rank> activeRanks = new ConcurrentHashMap<>();
    private volatile List<Rank> selectableRanks = List.of();
    private volatile Rank defaultRank = new Rank("default", "", 0, "<gray>PLAYER</gray>", "",
        Component.text("PLAYER"), Component.empty(), Component.text("PLAYER "));
    private volatile Component chatSeparator = Component.text(" » ");

    public RankService(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload(YamlConfiguration config) {
        List<String> warnings = new ArrayList<>();
        List<Rank> selectable = new ArrayList<>();
        Rank fallback = null;
        ConfigurationSection root = config == null ? null : config.getConfigurationSection("ranks");
        if (root != null) {
            for (String rawId : root.getKeys(false)) {
                String id = rawId.toLowerCase(java.util.Locale.ROOT);
                ConfigurationSection section = root.getConfigurationSection(rawId);
                if (section == null || !id.matches("[a-z0-9_-]+")) {
                    warnings.add("Skipping invalid rank definition '" + rawId + "'. Rank IDs must use lowercase letters, numbers, underscores, or hyphens.");
                    continue;
                }
                String permission = section.getString("permission", "");
                permission = permission == null ? "" : permission.trim();
                int priority = section.getInt("priority", id.equals("default") ? 0 : 1);
                String displayName = section.getString("display-name", id.toUpperCase(java.util.Locale.ROOT));
                displayName = displayName == null || displayName.isBlank() ? id.toUpperCase(java.util.Locale.ROOT) : displayName;
                String icon = section.getString("icon", "");
                icon = icon == null ? "" : icon.trim();
                if (icon.isBlank()) {
                    GlyphRegistry registry = plugin.glyphText().registry();
                    if (registry != null && registry.images().containsKey(id)) {
                        icon = GlyphRegistry.automaticRankIconTag(id);
                    }
                }
                if (!id.equals("default") && permission.isBlank()) {
                    warnings.add("Rank '" + id + "' has no permission node and will not be assigned. Set ranks." + id + ".permission in ranks.yml.");
                    continue;
                }
                Component displayComponent = plugin.glyphText().parse(displayName);
                Component iconComponent = icon.isBlank() ? Component.empty() : plugin.glyphText().parse(icon);
                Component prefix = Component.empty();
                if (!icon.isBlank()) {
                    prefix = prefix.append(iconComponent).append(Component.space());
                }
                prefix = prefix.append(displayComponent).append(Component.space());
                Rank rank = new Rank(id, permission, priority, displayName, icon,
                    displayComponent, iconComponent, prefix);
                if (id.equals("default")) {
                    fallback = rank;
                } else {
                    selectable.add(rank);
                }
            }
        }
        selectable.sort(Comparator.comparingInt(Rank::priority).reversed().thenComparing(Rank::id));
        if (fallback == null) {
            fallback = new Rank("default", "", 0, "<gray>PLAYER</gray>", "",
                plugin.glyphText().parse("<gray>PLAYER</gray>"), Component.empty(),
                plugin.glyphText().parse("<gray>PLAYER</gray>").append(Component.space()));
            warnings.add("ranks.yml has no valid 'default' rank; using a built-in PLAYER fallback.");
        }
        String separatorText = config == null ? "<dark_gray>»</dark_gray>" : config.getString("chat.separator", "<dark_gray>»</dark_gray>");
        chatSeparator = Component.space().append(plugin.glyphText().parse(separatorText)).append(Component.space());
        defaultRank = fallback;
        selectableRanks = List.copyOf(selectable);
        activeRanks.clear();
        refreshAll();
        for (String warning : warnings) {
            plugin.getLogger().warning(PluginMessages.text(warning));
        }
    }

    /** Refreshes rank permissions on the server thread; returns true when at least one rank changed. */
    public boolean refreshAll() {
        boolean changed = false;
        for (Player player : Bukkit.getOnlinePlayers()) {
            changed |= refresh(player);
        }
        return changed;
    }

    public boolean refresh(Player player) {
        Rank selected = defaultRank;
        for (Rank rank : selectableRanks) {
            if (player.hasPermission(rank.permission())) {
                selected = rank;
                break;
            }
        }
        Rank previous = activeRanks.put(player.getUniqueId(), selected);
        return previous == null || !previous.id().equals(selected.id());
    }

    public void remove(Player player) {
        activeRanks.remove(player.getUniqueId());
    }

    public Rank rank(Player player) {
        return activeRanks.getOrDefault(player.getUniqueId(), defaultRank);
    }

    public String rankName(Player player) {
        return rank(player).displayName();
    }

    public String rankIcon(Player player) {
        String icon = rank(player).icon();
        return icon.isBlank() ? "" : icon + " ";
    }

    public Component chatPrefix(Player player) {
        return rank(player).chatPrefix();
    }

    public Component chatSeparator() {
        return chatSeparator;
    }

    public record Rank(String id, String permission, int priority, String displayName, String icon,
                       Component displayComponent, Component iconComponent, Component chatPrefix) {}
}

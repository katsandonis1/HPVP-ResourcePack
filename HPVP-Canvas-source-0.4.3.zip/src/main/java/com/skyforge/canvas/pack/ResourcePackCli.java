package com.skyforge.canvas.pack;

import com.skyforge.canvas.util.PluginMessages;
import java.nio.file.Path;

/** Builds the same resource pack as /canvas pack build from a checked-out project folder. */
public final class ResourcePackCli {
    private ResourcePackCli() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException("Usage: ResourcePackCli <project-folder> <items.yml> <output-zip>");
        }
        Path project = Path.of(args[0]);
        Path items = Path.of(args[1]);
        Path output = Path.of(args[2]);
        ResourcePackBuilder.BuildResult result = ResourcePackBuilder.buildFromFiles(project, items, output);
        System.out.println(PluginMessages.text("Built resource pack: " + result.resourcePack()));
        System.out.println(PluginMessages.text("SHA-1: " + result.sha1()));
        for (String warning : result.warnings()) {
            System.out.println(PluginMessages.text("Warning: " + warning));
        }
        System.out.println(PluginMessages.text("Upload this ZIP unchanged. Its SHA-1 must match the plugin server's resourcepack.sha1."));
    }
}

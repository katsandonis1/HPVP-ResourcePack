package com.skyforge.canvas.pack;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;

/** Downloads a hosted ZIP as a stream and verifies it matches the server's generated pack. */
public final class HostedPackVerifier {
    private HostedPackVerifier() {}

    public static Verification verify(URI uri, long expectedBytes, String expectedSha1) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
        connection.setInstanceFollowRedirects(true);
        connection.setConnectTimeout(15_000);
        connection.setReadTimeout(120_000);
        connection.setUseCaches(false);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/zip, application/octet-stream, */*");
        connection.setRequestProperty("User-Agent", "HPVP-Canvas/1.0");

        try {
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK) {
                throw new IOException("The download URL returned HTTP " + status + ". Use a public direct link to the ZIP file.");
            }

            long contentLength = connection.getContentLengthLong();
            if (contentLength >= 0 && contentLength != expectedBytes) {
                throw sizeMismatch(contentLength, expectedBytes);
            }

            MessageDigest digest = sha1Digest();
            long downloaded = 0;
            byte[] buffer = new byte[16 * 1024];
            try (InputStream input = connection.getInputStream()) {
                int count;
                while ((count = input.read(buffer)) != -1) {
                    downloaded += count;
                    if (downloaded > expectedBytes) {
                        throw sizeMismatch(downloaded, expectedBytes);
                    }
                    digest.update(buffer, 0, count);
                }
            }

            if (downloaded != expectedBytes) {
                throw sizeMismatch(downloaded, expectedBytes);
            }
            String actualHash = HexFormat.of().formatHex(digest.digest());
            if (!actualHash.equalsIgnoreCase(expectedSha1)) {
                throw new IOException("The hosted ZIP SHA-1 is " + actualHash + ", but the generated pack SHA-1 is "
                    + expectedSha1.toLowerCase(Locale.ROOT) + ". Upload the exact resourcepack.zip created by /canvas pack build.");
            }
            return new Verification(downloaded, actualHash);
        } finally {
            connection.disconnect();
        }
    }

    private static IOException sizeMismatch(long actual, long expected) {
        return new IOException("The hosted file is " + actual + " bytes, but the generated resourcepack.zip is "
            + expected + " bytes. Upload the exact ZIP created by /canvas pack build.");
    }

    private static MessageDigest sha1Digest() throws IOException {
        try {
            return MessageDigest.getInstance("SHA-1");
        } catch (NoSuchAlgorithmException exception) {
            throw new IOException("SHA-1 is unavailable on this Java runtime.", exception);
        }
    }

    public record Verification(long bytes, String sha1) {}
}

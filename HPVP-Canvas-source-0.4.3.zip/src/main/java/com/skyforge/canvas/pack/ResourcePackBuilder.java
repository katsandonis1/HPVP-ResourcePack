package com.skyforge.canvas.pack;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.skyforge.canvas.CanvasPlugin;
import com.skyforge.canvas.util.GlyphRegistry;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.Deflater;
import javax.imageio.ImageIO;
import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public final class ResourcePackBuilder {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int PAUSE_LOGO_CODEPOINT = 0xF0000;
    private final CanvasPlugin plugin;

    public ResourcePackBuilder(CanvasPlugin plugin) {
        this.plugin = plugin;
    }

    public BuildResult build() throws IOException {
        plugin.glyphText().reload();
        Path data = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        GlyphRegistry glyphRegistry = plugin.glyphText().registry();
        if (glyphRegistry == null) {
            throw new IOException("Image glyphs could not be loaded. Check the plugin console for details.");
        }
        BuildResult result = build(data, plugin.itemsConfig(), glyphRegistry, plugin.pauseConfig(), data.resolve("resourcepack.zip"));
        boolean pauseEnabled = plugin.pauseConfig().getBoolean("pause-menu.enabled", true);
        if (pauseEnabled) {
            buildPauseDataPack(data);
        }
        return new BuildResult(result.resourcePack(), result.sha1(), result.warnings(),
            pauseEnabled ? data.resolve("pause-datapack.zip") : null);
    }

    public static BuildResult buildFromFiles(Path dataDirectory, Path itemsConfigFile, Path outputZip) throws IOException {
        Path data = dataDirectory.toAbsolutePath().normalize();
        Path itemConfig = itemsConfigFile.toAbsolutePath().normalize();
        Path output = outputZip.toAbsolutePath().normalize();
        if (!Files.isRegularFile(itemConfig)) {
            throw new IOException("Could not find items configuration: " + itemConfig);
        }
        YamlConfiguration items = YamlConfiguration.loadConfiguration(itemConfig.toFile());
        YamlConfiguration config = loadProjectConfiguration(data, "config.yml");
        YamlConfiguration tab = loadProjectConfiguration(data, "tab.yml");
        YamlConfiguration scoreboard = loadProjectConfiguration(data, "scoreboard.yml");
        YamlConfiguration pause = loadProjectConfiguration(data, "pause.yml");
        YamlConfiguration ranks = loadProjectConfiguration(data, "ranks.yml");
        GlyphRegistry registry = GlyphRegistry.load(data.resolve("glyphs"), config,
            GlyphRegistry.configuredText(tab, scoreboard, pause, ranks, data.resolve("glyphs")), ranks);
        return build(data, items, registry, pause, output);
    }

    private static BuildResult build(Path data, ConfigurationSection itemsConfig, GlyphRegistry glyphRegistry,
                                     ConfigurationSection pauseConfig,
                                     Path output) throws IOException {
        Path generated = data.resolve("generated/resource-pack").normalize();
        if (!generated.startsWith(data)) {
            throw new IOException("Generated pack path is outside the plugin folder.");
        }
        deleteTree(generated);
        Files.createDirectories(generated);
        Path assets = generated.resolve("assets");
        Files.createDirectories(assets);

        Path sourceAssets = data.resolve("pack-source/assets");
        if (Files.isDirectory(sourceAssets)) {
            copyTree(sourceAssets, assets);
        }

        List<String> warnings = new ArrayList<>(glyphRegistry.warnings());
        writeGlyphFont(assets, warnings, glyphRegistry);
        writePauseScreenBranding(data, assets, pauseConfig, warnings);
        writeItemModels(data, assets, warnings, itemsConfig);
        writeEquipmentModels(data, assets, warnings, itemsConfig);
        write(generated.resolve("pack.mcmeta"), "{\n  \"pack\": {\n    \"description\": \"ʜᴘᴠᴘ | HPVP-Canvas generated resource pack\",\n    \"min_format\": [75, 0],\n    \"max_format\": [75, 0]\n  }\n}\n");

        zipDirectory(generated, output);
        String hash = sha1(output);
        if (output.getParent().equals(data)) {
            Files.writeString(data.resolve("resourcepack.sha1"), hash + "\n", StandardCharsets.UTF_8);
        }

        return new BuildResult(output, hash, warnings, null);
    }

    private static void writeGlyphFont(Path assets, List<String> warnings, GlyphRegistry registry) throws IOException {
        Path textureFolder = assets.resolve("canvas/textures/font/images");
        Files.createDirectories(textureFolder);
        List<Map<String, Object>> providers = new ArrayList<>();
        Map<String, BufferedImage> imageCache = new HashMap<>();
        Map<ScaledGlyphKey, BufferedImage> scaledCache = new HashMap<>();
        for (GlyphRegistry.GlyphVariant variant : registry.variants()) {
            GlyphRegistry.VariantKey key = variant.key();
            String name = key.name();
            BufferedImage source = imageCache.get(name);
            if (source == null) {
                try {
                    source = ImageIO.read(variant.source().toFile());
                } catch (IOException exception) {
                    warnings.add("Could not read glyph image '" + name + "': " + exception.getMessage());
                    continue;
                }
                if (source == null) {
                    warnings.add("Invalid or unreadable glyph image: " + variant.source().getFileName());
                    continue;
                }
                imageCache.put(name, source);
            }
            ScaledGlyphKey scaledKey = new ScaledGlyphKey(name, key.width(), key.height(), key.filter());
            BufferedImage sourceImage = source;
            BufferedImage scaled = scaledCache.computeIfAbsent(scaledKey,
                ignored -> scaleImage(sourceImage, key.width(), key.height(), key.filter()));
            Path texture = textureFolder.resolve(variant.textureName());
            if (!ImageIO.write(scaled, "png", texture.toFile())) {
                throw new IOException("No PNG writer is available for glyph image '" + name + "'.");
            }
            Map<String, Object> provider = new LinkedHashMap<>();
            provider.put("type", "bitmap");
            provider.put("file", "canvas:font/images/" + variant.textureName());
            provider.put("ascent", ascent(key.height(), key.alignment()));
            provider.put("height", key.height());
            provider.put("chars", List.of(Character.toString(variant.character())));
            providers.add(provider);
        }
        Path font = assets.resolve("canvas/font/ui.json");
        Files.createDirectories(font.getParent());
        write(font, GSON.toJson(Map.of("providers", providers)) + "\n");
    }

    private static BufferedImage scaleImage(BufferedImage source, int width, int height,
                                            GlyphRegistry.SamplingFilter filter) {
        BufferedImage target = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = target.createGraphics();
        Object interpolation = switch (filter) {
            case NEAREST -> RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR;
            case BILINEAR -> RenderingHints.VALUE_INTERPOLATION_BILINEAR;
            case BICUBIC -> RenderingHints.VALUE_INTERPOLATION_BICUBIC;
        };
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, interpolation);
        graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
            filter == GlyphRegistry.SamplingFilter.NEAREST
                ? RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED
                : RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics.drawImage(source, 0, 0, width, height, null);
        graphics.dispose();
        return target;
    }

    private static int ascent(int height, GlyphRegistry.Alignment alignment) {
        return switch (alignment) {
            case TOP -> Math.min(height, 8);
            case CENTER -> Math.min(height, Math.max(1, (height + 7) / 2));
            case BOTTOM -> Math.max(1, height - 1);
        };
    }

    /** Adds a custom bitmap glyph and English translation overrides for the vanilla pause screen. */
    private static void writePauseScreenBranding(Path data, Path assets, ConfigurationSection pauseConfig,
                                                 List<String> warnings) throws IOException {
        String root = "pause-menu.native-branding";
        if (pauseConfig == null || !pauseConfig.getBoolean(root + ".enabled", true)) {
            return;
        }

        String configuredLocale = pauseConfig.getString(root + ".locale", "en_us");
        String locale = configuredLocale == null || configuredLocale.isBlank()
            ? "en_us" : configuredLocale.trim().toLowerCase(java.util.Locale.ROOT);
        if (!locale.matches("[a-z]{2}_[a-z]{2}")) {
            warnings.add(root + ".locale must look like en_us; using en_us.");
            locale = "en_us";
        }
        Path language = assets.resolve("minecraft/lang").resolve(locale + ".json");
        JsonObject languageJson = readJsonObjectOrEmpty(language, "Minecraft " + locale + " language file");

        String logoName = pauseConfig.getString(root + ".logo", "hellenic_logo");
        if (logoName != null && !logoName.isBlank() && !logoName.equalsIgnoreCase("none")) {
            logoName = logoName.trim().toLowerCase(java.util.Locale.ROOT);
            if (!logoName.matches("[a-z0-9_-]+")) {
                warnings.add(root + ".logo must be a simple PNG name such as hellenic_logo; the game-menu title was left unchanged.");
            } else {
                Path source = data.resolve("glyphs").resolve(logoName + ".png").normalize();
                if (!source.startsWith(data.resolve("glyphs").normalize()) || !Files.isRegularFile(source)) {
                    warnings.add("Missing pause-screen logo " + logoName + ".png under plugins/HPVP-Canvas/glyphs/; the game-menu title was left unchanged.");
                } else {
                    BufferedImage image;
                    try {
                        image = ImageIO.read(source.toFile());
                    } catch (IOException exception) {
                        throw new IOException("Could not read pause-screen logo " + source + ": " + exception.getMessage(), exception);
                    }
                    if (image == null || image.getWidth() < 1 || image.getHeight() < 1
                        || image.getWidth() > 4096 || image.getHeight() > 4096) {
                        warnings.add("Pause-screen logo " + logoName + ".png is invalid or exceeds 4096x4096; the game-menu title was left unchanged.");
                    } else {
                        int width = brandingDimension(pauseConfig, root + ".logo-width", 144, warnings);
                        int height = brandingDimension(pauseConfig, root + ".logo-height", 90, warnings);
                        int ascent = pauseConfig.getInt(root + ".logo-ascent", height / 2);
                        if (ascent < 0 || ascent > height) {
                            warnings.add(root + ".logo-ascent must be from 0 to logo-height; using the vertical center.");
                            ascent = height / 2;
                        }
                        Path texture = assets.resolve("minecraft/textures/font/hpvpcanvas_pause_logo.png");
                        Files.createDirectories(texture.getParent());
                        if (!ImageIO.write(scaleImage(image, width, height, GlyphRegistry.SamplingFilter.BICUBIC), "png", texture.toFile())) {
                            throw new IOException("No PNG writer is available for the pause-screen logo.");
                        }

                        JsonObject defaultFont = readJsonObjectOrEmpty(
                            assets.resolve("minecraft/font/default.json"), "Minecraft default font");
                        JsonArray providers = defaultFont.has("providers") && defaultFont.get("providers").isJsonArray()
                            ? defaultFont.getAsJsonArray("providers") : new JsonArray();
                        if (defaultFont.has("providers") && !defaultFont.get("providers").isJsonArray()) {
                            throw new IOException("Cannot add the pause-screen logo: assets/minecraft/font/default.json must contain a providers array.");
                        }
                        addFontReferenceIfMissing(providers, "minecraft:include/space", null);
                        JsonObject nonUniform = new JsonObject();
                        nonUniform.addProperty("uniform", false);
                        addFontReferenceIfMissing(providers, "minecraft:include/default", nonUniform);
                        addFontReferenceIfMissing(providers, "minecraft:include/unifont", null);

                        JsonObject logoProvider = new JsonObject();
                        logoProvider.addProperty("type", "bitmap");
                        logoProvider.addProperty("file", "minecraft:font/hpvpcanvas_pause_logo.png");
                        logoProvider.addProperty("height", height);
                        logoProvider.addProperty("ascent", ascent);
                        JsonArray chars = new JsonArray();
                        chars.add(new String(Character.toChars(PAUSE_LOGO_CODEPOINT)));
                        logoProvider.add("chars", chars);
                        providers.add(logoProvider);
                        defaultFont.add("providers", providers);
                        Path fontFile = assets.resolve("minecraft/font/default.json");
                        Files.createDirectories(fontFile.getParent());
                        write(fontFile, GSON.toJson(defaultFont) + "\n");
                        languageJson.addProperty("menu.game", new String(Character.toChars(PAUSE_LOGO_CODEPOINT)));
                    }
                }
            }
        }

        String disconnectLabel = pauseConfig.getString(root + ".disconnect-label", "§bLeave §fHellenic §9Network");
        if (disconnectLabel != null && !disconnectLabel.isBlank()) {
            languageJson.addProperty("menu.disconnect", disconnectLabel);
        }
        Files.createDirectories(language.getParent());
        write(language, GSON.toJson(languageJson) + "\n");
    }

    private static int brandingDimension(ConfigurationSection config, String key, int fallback, List<String> warnings) {
        int value = config.getInt(key, fallback);
        if (value < 1 || value > 256) {
            warnings.add(key + " must be from 1 to 256; using " + fallback + ".");
            return fallback;
        }
        return value;
    }

    private static void addFontReferenceIfMissing(JsonArray providers, String id, JsonObject filter) {
        for (JsonElement provider : providers) {
            if (!provider.isJsonObject()) {
                continue;
            }
            JsonObject object = provider.getAsJsonObject();
            JsonElement type = object.get("type");
            JsonElement referenceId = object.get("id");
            if (type != null && type.isJsonPrimitive() && type.getAsJsonPrimitive().isString()
                && "reference".equals(type.getAsString())
                && referenceId != null && referenceId.isJsonPrimitive() && referenceId.getAsJsonPrimitive().isString()
                && id.equals(referenceId.getAsString())) {
                return;
            }
        }
        JsonObject reference = new JsonObject();
        reference.addProperty("type", "reference");
        reference.addProperty("id", id);
        if (filter != null) {
            reference.add("filter", filter);
        }
        providers.add(reference);
    }

    private static JsonObject readJsonObjectOrEmpty(Path file, String label) throws IOException {
        if (!Files.isRegularFile(file)) {
            return new JsonObject();
        }
        try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            JsonElement root = JsonParser.parseReader(reader);
            if (!root.isJsonObject()) {
                throw new IOException(label + " at " + file + " must contain a JSON object.");
            }
            return root.getAsJsonObject();
        } catch (RuntimeException exception) {
            throw new IOException("Could not parse " + label + " at " + file + ": " + exception.getMessage(), exception);
        }
    }

    private static YamlConfiguration loadProjectConfiguration(Path data, String filename) {
        Path file = data.resolve(filename);
        if (!Files.isRegularFile(file)) {
            file = data.resolve("src/main/resources").resolve(filename);
        }
        return YamlConfiguration.loadConfiguration(file.toFile());
    }

    private static void writeItemModels(Path data, Path assets, List<String> warnings, ConfigurationSection itemsConfig) throws IOException {
        ConfigurationSection itemSection = itemsConfig == null ? null : itemsConfig.getConfigurationSection("items");
        if (itemSection == null) {
            return;
        }
        for (String id : itemSection.getKeys(false)) {
            ConfigurationSection item = itemSection.getConfigurationSection(id);
            if (item == null) {
                continue;
            }
            NamespacedPath itemModel;
            try {
                itemModel = NamespacedPath.parse(item.getString("model", "canvas:" + id));
            } catch (IllegalArgumentException exception) {
                warnings.add("Invalid item model key for '" + id + "': " + exception.getMessage());
                continue;
            }
            if ("minecraft".equals(itemModel.namespace())) {
                continue;
            }

            String texture = item.getString("texture", "").trim();
            boolean textureCopied = false;
            if (!texture.isEmpty()) {
                if (!validAssetPath(texture)) {
                    warnings.add("Invalid texture path for item '" + id + "': " + texture);
                    continue;
                }
                Path itemDirectory = data.resolve("items").normalize();
                Path sourceTexture = itemDirectory.resolve(texture + ".png").normalize();
                if (!sourceTexture.startsWith(itemDirectory)) {
                    warnings.add("Texture path for item '" + id + "' escapes the items folder.");
                    continue;
                }
                if (!Files.isRegularFile(sourceTexture)) {
                    warnings.add("Missing item texture " + texture + ".png for '" + id + "'. Add it under plugins/HPVP-Canvas/items/ or omit 'texture' when using a Blockbench model.");
                } else {
                    Path outputTexture = assets.resolve(itemModel.namespace()).resolve("textures/item").resolve(texture + ".png");
                    Files.createDirectories(outputTexture.getParent());
                    Files.copy(sourceTexture, outputTexture, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    textureCopied = true;
                }
            }

            Path definition = assets.resolve(itemModel.namespace()).resolve("items").resolve(itemModel.path() + ".json");
            Path modelFile = assets.resolve(itemModel.namespace()).resolve("models/item").resolve(itemModel.path() + ".json");
            Files.createDirectories(definition.getParent());
            Files.createDirectories(modelFile.getParent());
            if (!Files.exists(modelFile)) {
                if (!textureCopied) {
                    warnings.add("Missing model for custom item '" + id + "'. Add its Blockbench-exported JSON at pack-source/assets/" + itemModel.namespace() + "/models/item/" + itemModel.path() + ".json, or configure a valid texture.");
                    continue;
                }
                write(modelFile, "{\n  \"parent\": \"minecraft:item/generated\",\n  \"textures\": {\n    \"layer0\": \"" + itemModel.namespace() + ":item/" + jsonEscape(texture) + "\"\n  }\n}\n");
            } else {
                validateModelJson(modelFile, assets, warnings, "model for item '" + id + "'");
            }
            if (!Files.exists(definition)) {
                write(definition, "{\n  \"model\": {\n    \"type\": \"minecraft:model\",\n    \"model\": \"" + itemModel.namespace() + ":item/" + jsonEscape(itemModel.path()) + "\"\n  }\n}\n");
            } else {
                validateJsonFile(definition, warnings, "item definition for '" + id + "'");
            }
        }
    }

    private static void validateModelJson(Path modelFile, Path assets, List<String> warnings, String label) {
        JsonObject model;
        try (var reader = Files.newBufferedReader(modelFile, StandardCharsets.UTF_8)) {
            JsonElement root = JsonParser.parseReader(reader);
            if (!root.isJsonObject()) {
                warnings.add("Invalid " + label + ": the model JSON must contain an object.");
                return;
            }
            model = root.getAsJsonObject();
        } catch (IOException | RuntimeException exception) {
            warnings.add("Could not read " + label + " JSON: " + exception.getMessage());
            return;
        }

        JsonElement parent = model.get("parent");
        if (parent != null && parent.isJsonPrimitive() && parent.getAsJsonPrimitive().isString()) {
            try {
                NamespacedPath parentId = NamespacedPath.parse(parent.getAsString(), "minecraft");
                if (!"minecraft".equals(parentId.namespace())) {
                    Path parentFile = assets.resolve(parentId.namespace()).resolve("models").resolve(parentId.path() + ".json");
                    if (!Files.isRegularFile(parentFile)) {
                        warnings.add("Missing parent model " + parentId.namespace() + ":" + parentId.path() + " used by " + label + ".");
                    }
                }
            } catch (IllegalArgumentException exception) {
                warnings.add("Invalid parent model in " + label + ": " + exception.getMessage());
            }
        }

        JsonElement textures = model.get("textures");
        if (textures == null || !textures.isJsonObject()) {
            return;
        }
        for (Map.Entry<String, JsonElement> entry : textures.getAsJsonObject().entrySet()) {
            JsonElement textureElement = entry.getValue();
            if (!textureElement.isJsonPrimitive() || !textureElement.getAsJsonPrimitive().isString()) {
                warnings.add("Invalid texture entry '" + entry.getKey() + "' in " + label + ".");
                continue;
            }
            String value = textureElement.getAsString();
            if (value.startsWith("#")) {
                continue;
            }
            try {
                NamespacedPath textureId = NamespacedPath.parse(value, "minecraft");
                if (!"minecraft".equals(textureId.namespace())) {
                    Path textureFile = assets.resolve(textureId.namespace()).resolve("textures").resolve(textureId.path() + ".png");
                    if (!Files.isRegularFile(textureFile)) {
                        warnings.add("Missing texture " + textureId.namespace() + ":" + textureId.path() + " referenced by " + label + ".");
                    }
                }
            } catch (IllegalArgumentException exception) {
                warnings.add("Invalid texture reference '" + value + "' in " + label + ".");
            }
        }
    }

    private static void validateJsonFile(Path jsonFile, List<String> warnings, String label) {
        try (var reader = Files.newBufferedReader(jsonFile, StandardCharsets.UTF_8)) {
            if (!JsonParser.parseReader(reader).isJsonObject()) {
                warnings.add("Invalid " + label + ": expected a JSON object.");
            }
        } catch (IOException | RuntimeException exception) {
            warnings.add("Could not read " + label + " JSON: " + exception.getMessage());
        }
    }

    private static void validateEquipmentJson(Path jsonFile, Path assets, List<String> warnings, String label) {
        JsonObject equipment;
        try (var reader = Files.newBufferedReader(jsonFile, StandardCharsets.UTF_8)) {
            JsonElement root = JsonParser.parseReader(reader);
            if (!root.isJsonObject()) {
                warnings.add("Invalid " + label + ": expected a JSON object.");
                return;
            }
            equipment = root.getAsJsonObject();
        } catch (IOException | RuntimeException exception) {
            warnings.add("Could not read " + label + " JSON: " + exception.getMessage());
            return;
        }

        for (Map.Entry<String, JsonElement> layerEntry : equipment.entrySet()) {
            if (!layerEntry.getValue().isJsonArray()) {
                continue;
            }
            for (JsonElement layerElement : layerEntry.getValue().getAsJsonArray()) {
                if (!layerElement.isJsonObject()) {
                    warnings.add("Invalid layer entry in '" + layerEntry.getKey() + "' for " + label + ".");
                    continue;
                }
                JsonElement textureElement = layerElement.getAsJsonObject().get("texture");
                if (textureElement == null || !textureElement.isJsonPrimitive() || !textureElement.getAsJsonPrimitive().isString()) {
                    warnings.add("A layer in '" + layerEntry.getKey() + "' is missing its texture in " + label + ".");
                    continue;
                }
                try {
                    NamespacedPath textureId = NamespacedPath.parse(textureElement.getAsString(), "minecraft");
                    if (!"minecraft".equals(textureId.namespace())) {
                        Path textureFile = assets.resolve(textureId.namespace())
                            .resolve("textures/entity/equipment")
                            .resolve(layerEntry.getKey())
                            .resolve(textureId.path() + ".png");
                        if (!Files.isRegularFile(textureFile)) {
                            warnings.add("Missing equipment texture " + textureId.namespace() + ":" + textureId.path() + " for layer '" + layerEntry.getKey() + "'.");
                        }
                    }
                } catch (IllegalArgumentException exception) {
                    warnings.add("Invalid equipment texture reference '" + textureElement.getAsString() + "' in " + label + ".");
                }
            }
        }
    }

    private static boolean validAssetPath(String path) {
        return path.matches("[a-z0-9_/-]+") && !path.contains("..") && !path.startsWith("/") && !path.endsWith("/");
    }

    private static void writeEquipmentModels(Path data, Path assets, List<String> warnings, ConfigurationSection itemsConfig) throws IOException {
        ConfigurationSection itemSection = itemsConfig == null ? null : itemsConfig.getConfigurationSection("items");
        if (itemSection == null) {
            return;
        }
        for (String id : itemSection.getKeys(false)) {
            ConfigurationSection item = itemSection.getConfigurationSection(id);
            ConfigurationSection equipment = item == null ? null : item.getConfigurationSection("equipment");
            if (equipment == null) {
                continue;
            }
            NamespacedPath asset;
            try {
                asset = NamespacedPath.parse(equipment.getString("asset", "canvas:armor"));
            } catch (IllegalArgumentException exception) {
                warnings.add("Invalid equipment asset for '" + id + "': " + exception.getMessage());
                continue;
            }
            String texture = equipment.getString("texture", asset.path());
            if (!validAssetPath(texture)) {
                warnings.add("Invalid armor texture path for item '" + id + "': " + texture);
                continue;
            }
            Path definition = assets.resolve(asset.namespace()).resolve("equipment").resolve(asset.path() + ".json");
            if (Files.isRegularFile(definition)) {
                validateEquipmentJson(definition, assets, warnings, "equipment definition for '" + id + "'");
                continue;
            }
            Path humanoidSource = data.resolve("armor").resolve(texture + ".png");
            Path leggingsSource = data.resolve("armor").resolve(texture + "_leggings.png");
            Path humanoidOut = assets.resolve(asset.namespace()).resolve("textures/entity/equipment/humanoid").resolve(asset.path() + ".png");
            Path leggingsOut = assets.resolve(asset.namespace()).resolve("textures/entity/equipment/humanoid_leggings").resolve(asset.path() + ".png");
            Files.createDirectories(humanoidOut.getParent());
            Files.createDirectories(leggingsOut.getParent());
            List<Map<String, String>> humanoidLayers = new ArrayList<>();
            List<Map<String, String>> leggingsLayers = new ArrayList<>();
            if (Files.isRegularFile(humanoidSource)) {
                Files.copy(humanoidSource, humanoidOut, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                humanoidLayers.add(Map.of("texture", asset.namespace() + ":" + asset.path()));
            } else {
                warnings.add("Missing armor texture " + humanoidSource.getFileName() + " for '" + id + "'. Add it under plugins/HPVP-Canvas/armor/.");
            }
            if (Files.isRegularFile(leggingsSource)) {
                Files.copy(leggingsSource, leggingsOut, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                leggingsLayers.add(Map.of("texture", asset.namespace() + ":" + asset.path()));
            }
            Map<String, Object> layers = new LinkedHashMap<>();
            if (!humanoidLayers.isEmpty()) {
                layers.put("humanoid", humanoidLayers);
            }
            if (!leggingsLayers.isEmpty()) {
                layers.put("humanoid_leggings", leggingsLayers);
            }
            if (humanoidLayers.isEmpty() && leggingsLayers.isEmpty()) {
                continue;
            }
            Files.createDirectories(definition.getParent());
            write(definition, GSON.toJson(layers) + "\n");
        }
    }

    private void buildPauseDataPack(Path data) throws IOException {
        Path generated = data.resolve("generated/pause-datapack");
        deleteTree(generated);
        Path dialog = generated.resolve("data/canvas/dialog/pause.json");
        Path tag = generated.resolve("data/minecraft/tags/dialog/pause_screen_additions.json");
        Files.createDirectories(dialog.getParent());
        Files.createDirectories(tag.getParent());

        String title = componentJson(plugin.glyphText().parse(plugin.pauseConfig().getString("pause-menu.title", "Server Info")));
        String buttonTitle = componentJson(plugin.glyphText().parse(plugin.pauseConfig().getString("pause-menu.button-title", "Server Info")));
        String message = componentJson(plugin.glyphText().parse(plugin.pauseConfig().getString("pause-menu.message", "Welcome to the server.")));
        String close = componentJson(plugin.glyphText().parse(plugin.pauseConfig().getString("pause-menu.close-button", "Back to Game")));
        write(dialog, "{\n"
            + "  \"type\": \"minecraft:notice\",\n"
            + "  \"title\": " + title + ",\n"
            + "  \"external_title\": " + buttonTitle + ",\n"
            + "  \"body\": [{\"type\": \"minecraft:plain_message\", \"contents\": " + message + ", \"width\": 300}],\n"
            + "  \"action\": {\"label\": " + close + "},\n"
            + "  \"pause\": false\n"
            + "}\n");
        write(tag, "{\n  \"replace\": false,\n  \"values\": [\"canvas:pause\"]\n}\n");
        write(generated.resolve("pack.mcmeta"), "{\n  \"pack\": {\n    \"description\": \"ʜᴘᴠᴘ | HPVP-Canvas pause menu dialog\",\n    \"min_format\": [94, 1],\n    \"max_format\": [94, 1]\n  }\n}\n");
        zipDirectory(generated, data.resolve("pause-datapack.zip"));
    }

    private static String componentJson(net.kyori.adventure.text.Component component) {
        return GsonComponentSerializer.gson().serialize(component);
    }

    private static void write(Path path, String content) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, content, StandardCharsets.UTF_8);
    }

    private static void copyTree(Path source, Path target) throws IOException {
        try (var paths = Files.walk(source)) {
            for (Path path : paths.toList()) {
                Path relative = source.relativize(path);
                Path destination = target.resolve(relative.toString());
                if (Files.isDirectory(path)) {
                    Files.createDirectories(destination);
                } else {
                    Files.createDirectories(destination.getParent());
                    Files.copy(path, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private static void zipDirectory(Path directory, Path output) throws IOException {
        Files.createDirectories(output.getParent());
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(output)))) {
            zip.setLevel(Deflater.BEST_COMPRESSION);
            try (var paths = Files.walk(directory)) {
                for (Path path : paths.filter(Files::isRegularFile).sorted().toList()) {
                    String entryName = directory.relativize(path).toString().replace('\\', '/');
                    ZipEntry entry = new ZipEntry(entryName);
                    entry.setTimeLocal(java.time.LocalDateTime.of(1980, 1, 1, 0, 0));
                    zip.putNextEntry(entry);
                    try (InputStream input = new BufferedInputStream(Files.newInputStream(path))) {
                        input.transferTo(zip);
                    }
                    zip.closeEntry();
                }
            }
        }
    }

    public static String sha1(Path file) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            try (InputStream input = Files.newInputStream(file)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    digest.update(buffer, 0, read);
                }
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (java.security.NoSuchAlgorithmException exception) {
            throw new IOException("SHA-1 is unavailable", exception);
        }
    }

    private static void deleteTree(Path path) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        try (var paths = Files.walk(path)) {
            for (Path item : paths.sorted(Comparator.reverseOrder()).toList()) {
                Files.deleteIfExists(item);
            }
        }
    }

    private static String jsonEscape(String input) {
        return input.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private record NamespacedPath(String namespace, String path) {
        private static NamespacedPath parse(String value) {
            return parse(value, "canvas");
        }

        private static NamespacedPath parse(String value, String defaultNamespace) {
            if (value == null || value.isBlank()) {
                throw new IllegalArgumentException("Asset key cannot be blank.");
            }
            String[] split = value.split(":", 2);
            String namespace = split.length == 2 ? split[0] : defaultNamespace;
            String path = split.length == 2 ? split[1] : split[0];
            if (!namespace.matches("[a-z0-9_.-]+") || !path.matches("[a-z0-9/._-]+")
                || path.contains("..") || path.startsWith("/") || path.endsWith("/")) {
                throw new IllegalArgumentException("Invalid namespaced asset key: " + value);
            }
            return new NamespacedPath(namespace, path);
        }
    }

    private record ScaledGlyphKey(String name, int width, int height, GlyphRegistry.SamplingFilter filter) {}

    public record BuildResult(Path resourcePack, String sha1, List<String> warnings, Path pauseDataPack) {}
}

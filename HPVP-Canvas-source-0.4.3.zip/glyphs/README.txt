Place PNG images in this folder, for example logo.png, then refer to them as <image:logo> in HPVP-Canvas text configuration. Run /canvas pack build after changing images.

hellenic_logo.png is also the bundled logo for the native pause-screen title. Its appearance and the Leave Hellenic Network button label are configured in pause.yml under pause-menu.native-branding.

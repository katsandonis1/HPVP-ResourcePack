# HPVP-Canvas

HPVP-Canvas is a Paper plugin for a Minecraft Java PvP server. This release targets **Paper 1.21.11** and **Java 21**. Install it on the Paper PvP backend behind Velocity; it is not a Velocity proxy plugin.

It includes an in-plugin tab header/footer and player-name format, a sidebar scoreboard, custom bitmap glyphs for supported text areas, custom item models, custom armor equipment layers, and an exportable pause-menu dialog data pack.

## Build and install

1. Install JDK 21 and Gradle 8.14 or newer, or open this folder in IntelliJ IDEA and import it as a Gradle project.
2. From this folder, run `gradle jar exportResourcePack`.
3. The plugin JAR is `build/libs/HPVP-Canvas-0.4.3.jar`. The ready-to-host pack generated from this project's files is `build/generated/HPVP-Canvas-resourcepack.zip`; it contains configured static and animated glyph variants plus assets in `pack-source/assets/`.
4. Replace the old HPVP-Canvas JAR in the `plugins` folder of the **Paper PvP server** behind Velocity so only one HPVP-Canvas JAR remains, then restart the Paper server.
5. Start the Paper server once. HPVP-Canvas creates `plugins/HPVP-Canvas/` with its configuration and asset folders. When upgrading from the earlier `Canvas` plugin name, it copies existing files into the new folder.
6. Edit the YAML files and add your PNGs as described below. The offline Gradle task reads the project files; the server command reads the live `plugins/HPVP-Canvas/` files. If you added assets only on the server, build and download the server-generated ZIP instead of using the project ZIP.
7. On the Paper server, run `/canvas pack build`. It creates `plugins/HPVP-Canvas/resourcepack.zip`, `plugins/HPVP-Canvas/resourcepack.sha1`, and, when enabled, `plugins/HPVP-Canvas/pause-datapack.zip`.
8. Download that exact `resourcepack.zip` through the server host's file manager or SFTP and upload it unchanged to a public host. Do not unzip or repackage it. For the first setup, run `/canvas pack set <url>`; HPVP-Canvas downloads the hosted file in the background, checks its size and SHA-1 against the generated pack, then saves the URL and prompts players.
   For later pack changes, run `/canvas pack build`, upload the new ZIP over the old hosted file unchanged, then run `/canvas pack update`. This rechecks the saved URL, saves the new verified hash, and prompts online players. An outdated hosted ZIP is rejected; the plugin cannot upload files to your external host for you.
9. To enable the pause-menu button, copy `pause-datapack.zip` into the PvP world’s `datapacks` folder and run `/reload` or restart the server. The pause button opens a standard Minecraft dialog. Add or merge the generated tag with any existing `minecraft:pause_screen_additions` customization.

The pack builder writes the 1.21.11 resource-pack format (75.0) and data-pack format (94.1). Minecraft 1.21.11 supports the data-driven pause-screen dialog feature used here. See the official [1.21.11 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11) and [Paper setup guide](https://docs.papermc.io/paper/dev/project-setup/).

## Features and commands

- `/canvas reload` reloads HPVP-Canvas YAML files and refreshes the built-in tab and scoreboard for online players.
- `/canvas pack build` generates the resource pack, its SHA-1 file, and the pause-menu data pack. The output path is printed so you can download the exact ZIP from your Paper host.
- `/canvas pack set <url>` checks that the public URL serves the same bytes as the generated `resourcepack.zip`, stores the URL and verified hash in `config.yml`, keeps the pack optional, and then prompts online players. Run `/canvas pack build` first.
- `/canvas pack update` verifies the newly built ZIP at the already-saved URL, records its current SHA-1, and prompts online players. Run `/canvas pack build`, upload the resulting ZIP to the saved URL unchanged, and then run this command. It reports a hash or size mismatch if the hosted file has not been replaced.
- `/canvas give <player> <item>` gives a custom item defined in `items.yml`.
- All commands use the `canvas.admin` permission, granted to operators by default.
- Plugin chat responses, permission errors, and console messages use the `ʜᴘᴠᴘ | ` prefix. The plugin is named **HPVP-Canvas**; the command remains `/canvas`.

The tab and sidebar are managed directly by HPVP-Canvas. No TAB, SimpleScore, PlaceholderAPI, or Multiverse dependency is required. The UI also supports `%world_players%`, `%world_player_list%`, `%rank%`, and `%rank_icon%` as documented below.

## Configurable image glyphs

Put a PNG in `plugins/HPVP-Canvas/glyphs/`, for example `logo.png`, then reference it in `tab.yml`, `scoreboard.yml`, or `pause.yml`. Examples:

    tab:
      header:
        - "<image:left,size:16,color:#ffffff,align:center>"

    scoreboard:
      title: "<image:left,size:12,align:center> <aqua><bold>HELLENIC PvP</bold></aqua>"

    pause-menu:
      message: "Welcome! <image:left,width:32,height:16,align:center>"

Tag options:

- `size:N` displays a square `N×N` glyph, for example `<image:left,size:16>`.
- `width:N,height:N` sets an exact rectangle; provide both options together.
- `color:name` or `color:#RRGGBB` applies a MiniMessage text tint. Supported names include the 16 Minecraft colors plus `orange`, `pink`, `cyan`, `purple`, `lime`, `navy`, and `teal`.
- `align:top`, `align:center`, or `align:bottom` adjusts the glyph against the text baseline.
- `filter:nearest`, `filter:bilinear`, or `filter:bicubic` selects pixel-art or smoother resampling. Set `image-glyphs.default-filter` in `config.yml`, or override it for one tag.

Combine options like `<image:left,size:16,color:red,align:center>`. Existing `<image:left>` tags stay supported and use these defaults from `config.yml`:

    image-glyphs:
      default-size: original # or a square size such as 16
      max-size: 64
      default-color: none
      default-align: bottom
      default-filter: nearest

The configured maximum applies to each output dimension; it defaults to 64 and cannot exceed 256. Large source PNGs can be downscaled with `size` or `width`/`height`, but source images larger than 2048×2048 are rejected. If the requested output is larger than the source PNG, HPVP-Canvas warns that upscaling cannot restore lost detail. Use monochrome white/transparent PNGs for predictable color tinting. Full-color artwork keeps its source colors when no MiniMessage color styling is applied; a surrounding text color can tint it.

HPVP-Canvas scans image tags in the tab, scoreboard, pause, and rank configs, then deterministically registers each unique image, size, alignment, and filter variant in the resource pack. Source PNGs and resized variants are cached while building. Minecraft can only render the pixels in the configured glyph dimensions, and the client GUI scale changes their apparent on-screen size. After changing an image, tag option, or default, run `/canvas pack build`, upload the new ZIP unchanged, and run `/canvas pack update` so its hosted hash is verified and online players receive the updated pack. PNG names must use lowercase letters, numbers, underscores, or hyphens; names are matched case-insensitively.

The plugin keeps Minecraft's normal pixel-style text and its generated image-glyph font. Chat and console notices retain the requested `ʜᴘᴠᴘ | ` signature.

## Animated glyphs

Add at least two PNG frames to `plugins/HPVP-Canvas/glyphs/`, then configure them in `config.yml`:

```yaml
animations:
  logo:
    frames: [logo_1, logo_2, logo_3]
    frame-interval-ticks: 10
```

Place `<animate:logo,size:16,align:center>` in a tab header/footer or scoreboard title/line. `frame-interval-ticks` accepts 2 through 1200 ticks. The plugin uses one shared scheduler and only resends UI when a frame changes or its configured data refreshes. All animation PNGs are included in `/canvas pack build`; upload the new ZIP and run `/canvas pack update`. The pause dialog is static while open. Rank icons in chat are rendered with the chat message and do not continuously animate.

## UI refresh rates

Set the tab and scoreboard refresh rates separately in `config.yml`:

```yaml
ui:
  tab-update-interval-ticks: 20
  scoreboard-update-interval-ticks: 20
```

20 ticks is about one second. Each setting accepts 5 through 1200 ticks. Shorter intervals refresh ping, health, counts, same-world roster text, ranks, and other configured placeholders more often, at the cost of additional UI updates. A single shared task handles the refreshes; unchanged components are not resent.

## Multiverse world roster

The built-in tab header and scoreboard can show players in the viewer's current Bukkit world, including Multiverse worlds, with `%world_players%` and `%world_player_list%`. The sample `tab.yml` includes a bounded roster line; set `tab.world-roster-max-players` to control its maximum names. World changes and cross-world teleports refresh the roster. No Multiverse plugin integration is required.

Paper's standard player-list name is set on the player, not separately for each viewer, and `hidePlayer` also hides that player's entity. HPVP-Canvas therefore does not hide players from other worlds in the native tab rows. The same-world roster shown in the plugin-managed tab header and scoreboard is per viewer; the native list rows remain global. See the [Paper Player API](https://jd.papermc.io/paper/1.21.11/org/bukkit/entity/Player.html).

## Ranks and chat icons

Edit `plugins/HPVP-Canvas/ranks.yml`. Ranks match permission nodes; if a player has more than one, the highest `priority` wins. Operators can grant nodes with their permission manager, for example `hpvp.rank.vip` or `hpvp.rank.owner`.

```yaml
ranks:
  vip:
    permission: "hpvp.rank.vip"
    priority: 50
    display-name: "<aqua>VIP</aqua>"
    icon: "" # auto-detects glyphs/vip.png; leave blank for auto-detection
  owner:
    permission: "hpvp.rank.owner"
    priority: 100
    display-name: "<red><bold>OWNER</bold></red>"
    icon: "" # auto-detects glyphs/owner.png
```

The bundled `glyphs/left.png` is used by the sample tab and scoreboard, and `glyphs/owner.png` is the automatic Owner-rank icon. When `icon` is blank, HPVP-Canvas looks for a PNG named after the rank ID in `plugins/HPVP-Canvas/glyphs/`: rank ID `vip` uses `vip.png`, and rank ID `owner` uses `owner.png`. File-name matching is case-insensitive. A found image is displayed at 10×10 beside the rank's configured `display-name` and the player's name in both the tab list and chat. If the PNG is missing or invalid, the configured rank display text is used without an icon. Set `icon` to an explicit glyph tag only when you want to override the automatic file lookup. Players need the resource pack to see custom glyphs. After adding or replacing a rank image, run `/canvas reload`, then `/canvas pack build`, upload the ZIP unchanged, and run `/canvas pack update`. Rank permission assignments refresh at the tab interval. Chat messages use Paper's chat renderer and the original message component; other chat-formatting plugins may replace the renderer and should be checked for compatibility.

## Blockbench models

Use Blockbench's **Minecraft: Java Block/Item** format and export the model as a Java model JSON plus its PNG texture. A `.bbmodel` is a Blockbench project file and is not loaded by the plugin directly; export the Minecraft Java files from Blockbench first. See the [Blockbench format guide](https://blockbench.net/wiki/blockbench/formats/) and [export guide](https://blockbench.net/wiki/guides/export-formats/).

For a custom item named `hellenic_blade`:

1. Put the model JSON at `plugins/HPVP-Canvas/pack-source/assets/hpvp/models/item/hellenic_blade.json`.
2. Put its texture at `plugins/HPVP-Canvas/pack-source/assets/hpvp/textures/item/hellenic_blade.png`.
3. In the model JSON, use the full texture ID `hpvp:item/hellenic_blade` (and reference it from the model's texture entries).
4. Add this item to `items.yml`:

```yaml
items:
  hellenic_blade:
    material: NETHERITE_SWORD
    name: "<gradient:#38bdf8:#ffffff><bold>Hellenic Blade</bold></gradient>"
    lore:
      - "<gray>Forged for the arena."
    model: "hpvp:hellenic_blade"
```

The plugin preserves Blockbench model JSON, including its elements, rotations, and display transforms. It creates the 1.21.11 item-model definition that connects `hpvp:hellenic_blade` to `hpvp:item/hellenic_blade`. You can also provide your own item-model definition at `plugins/HPVP-Canvas/pack-source/assets/hpvp/items/hellenic_blade.json`; the builder will keep it and check that it is valid JSON. Run `/canvas pack build` after adding or changing models. Missing or invalid JSON and referenced texture files are reported in the command output with the `ʜᴘᴠᴘ | ` prefix.

For a flat item texture instead of a 3D Blockbench model, put a PNG in `plugins/HPVP-Canvas/items/` and set `texture:` in `items.yml`; the builder generates a basic item model for it.

Minecraft 1.21.11 uses the newer item-model layout under `assets/<namespace>/items/` and the model JSON under `assets/<namespace>/models/`. The resource-pack format is 75.0. Keep an item's textures on the same atlas as required by Minecraft's model rules. See the [1.21.11 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11) and [1.21.4 item-model changes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-4).

## Custom items and armor

`items.yml` starts with an empty item list so a fresh resource pack does not report missing example textures. A ready-to-copy Blockbench sword example is documented above; enable it after adding its model and texture files. Flat-texture items can use a PNG named by `texture:` in `plugins/HPVP-Canvas/items/`; the builder creates an item-model definition and generated model for it. For more complex 3D models, add the Minecraft resource-pack files under `plugins/HPVP-Canvas/pack-source/assets/`; HPVP-Canvas preserves those files when it builds the pack.

For a custom worn armor appearance, add a player-layer texture at `plugins/HPVP-Canvas/armor/<texture>.png`. For leggings, also add `plugins/HPVP-Canvas/armor/<texture>_leggings.png`. The equipment asset ID and slot are set in the item's `equipment` section. Armor texture UV layouts must match Minecraft’s humanoid equipment layout. You can provide equipment definitions and textures through `pack-source/assets/<namespace>/equipment/` and `pack-source/assets/<namespace>/textures/entity/equipment/`.

For example, set `asset: "hpvp:hellenic_armor"` in `items.yml`, then place its equipment definition at `pack-source/assets/hpvp/equipment/hellenic_armor.json`. Use `humanoid` and `humanoid_leggings` texture layers in that JSON, with the corresponding PNGs under `textures/entity/equipment/humanoid/` and `textures/entity/equipment/humanoid_leggings/`. The builder validates each custom texture reference.

Vanilla equipment assets control the worn texture layers, not arbitrary Blockbench geometry. A Blockbench item model can change how an item looks in the inventory and hand; its custom geometry does not become a custom 3D worn armor model through a resource pack alone. Worn armor keeps Minecraft's supported equipment shape and uses the custom layer textures.

The generated resource pack uses the item model key from each item definition. Players need the matching pack to see the custom appearance. If a configured item or armor texture is missing, `/canvas pack build` prints a warning and skips the affected generated asset.

## Pause menu limits

Vanilla Minecraft does not let a server plugin replace the pause-screen layout or place arbitrary image panels around its buttons. On 1.21.11, a data pack can add a pause-screen button that opens a standard dialog. HPVP-Canvas exports that data pack and lets the dialog include custom font glyphs. Minecraft currently marks dialogs as experimental and displays a notice icon on them. The dialog remains within Minecraft’s built-in layout; reproducing the screenshot’s side panels would require a client mod. See the official [1.21.11 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11) and [pause-screen dialog notes](https://www.minecraft.net/en-us/article/minecraft-snapshot-25w20a).

### Native pause-screen branding

HPVP-Canvas can use the accepted server resource pack to put a logo in the native **Game Menu** title position and rename the native **Disconnect** button. The current defaults use the bundled `glyphs/hellenic_logo.png` and blue, white, and navy text: `Leave Hellenic Network`. This uses a custom bitmap font glyph and an `en_us` translation override; it keeps Minecraft’s regular button layout. It does not add extra logo panels or change what the button does.

Edit `plugins/HPVP-Canvas/pause.yml`:

    pause-menu:
      native-branding:
        enabled: true
        logo: hellenic_logo
        logo-width: 144
        logo-height: 90
        logo-ascent: 45
        locale: en_us
        disconnect-label: "§bLeave §fHellenic §9Network"

Put another logo at `plugins/HPVP-Canvas/glyphs/<name>.png` and set `logo: <name>`. Width and height control the displayed bitmap dimensions (1–256 each), and `logo-ascent` positions it against the title baseline (0 through the configured height). Set `logo: none` to keep Minecraft’s regular title text. `disconnect-label` accepts Minecraft legacy color codes, such as `§b` for aqua, `§f` for white, and `§9` for dark blue. `locale` chooses which client language file is overridden; English (US) is the default, so clients using a different language keep their normal title and button label unless you select that locale.

After editing the logo, size, locale, or label, run `/canvas pack build`, upload the newly generated `resourcepack.zip` unchanged to the same direct HTTPS URL, and run `/canvas pack update`. The updated title and label appear after the client accepts/reloads the pack. A resource pack replaces the selected language entry and `minecraft:font/default.json`; other packs that also replace those same files may conflict. The font keeps Minecraft’s built-in font references, but custom font providers from another pack may need to be merged manually.

## Velocity notes

Install HPVP-Canvas only on the Paper PvP backend. The HTTPS resource-pack URL must be reachable by players’ Minecraft clients, not just by the proxy or backend machine. If another backend also sends a server resource pack, coordinate those requests so players receive the intended pack when routed to PvP. HPVP-Canvas does not need to be installed on the Velocity proxy.

## Configuration files

- `config.yml`: resource-pack URL and prompt, pack requirement, UI refresh intervals, image-glyph defaults and limits, and animation definitions.
- `tab.yml`: player-list header, footer, and player names.
- `scoreboard.yml`: sidebar title and lines. Refresh intervals are in `config.yml`.
- `items.yml`: custom item definitions and equipment models.
- `pause.yml`: pause button title and dialog content.
- `ranks.yml`: rank permissions, priority, display names, optional glyph icons, and chat separator.

## Resource-pack download troubleshooting

If Minecraft reports `Hash of downloaded file ... did not match requested`, the URL is serving a different ZIP from the one the Paper server generated. Replace the hosted file with the exact `resourcepack.zip` from the current server build, leave its bytes unchanged, and run `/canvas pack set <url>` again. The plugin verifies the complete hosted download and will not send a stale or mismatched pack to players. A GitHub URL must point to the raw ZIP download, not the repository `blob` or `blame` page.

Place advanced resource-pack assets under `assets/<namespace>/...` in this folder. HPVP-Canvas copies them into its generated resource pack before writing generated files.

For a Blockbench Java item model, use:

- `assets/<namespace>/models/item/<model>.json`
- `assets/<namespace>/textures/item/<texture>.png`

Set the matching namespaced item key in `items.yml`, such as `hpvp:hellenic_blade`, and reference the texture in the model JSON as `hpvp:item/hellenic_blade`. HPVP-Canvas creates the matching `assets/<namespace>/items/<model>.json` definition unless you provide that definition yourself. Raw `.bbmodel` project files are not runtime models; export the Java model JSON and PNG textures from Blockbench first.

For worn armor, place an equipment definition at `assets/<namespace>/equipment/<asset>.json` and its layer textures under `assets/<namespace>/textures/entity/equipment/<layer>/`. Equipment models select texture layers; they do not define custom 3D worn armor geometry.
